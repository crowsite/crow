# Overview

This is a modern full-stack gaming digital store application built with React/TypeScript frontend and Express.js backend. The platform allows users to browse, purchase, and manage digital games with features like shopping cart, user library, and wishlist functionality. It includes an admin dashboard for product and order management, along with a storage management system for tracking game installations and downloads.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
- **Framework**: React 18 with TypeScript using Vite as the build tool
- **Routing**: Wouter for lightweight client-side routing
- **State Management**: TanStack Query for server state management, custom hooks for local state (cart, mobile detection)
- **UI Components**: shadcn/ui component library with Radix UI primitives
- **Styling**: Tailwind CSS with custom gaming-themed design system featuring neon colors and dark theme
- **Component Structure**: Organized into feature-based folders (admin, games, cart, storage, layout)

## Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Language**: TypeScript with ES modules
- **API Design**: RESTful endpoints with proper HTTP status codes and error handling
- **Data Validation**: Zod schemas for request/response validation
- **Middleware**: Custom logging middleware for API requests with timing and response tracking
- **Development**: Hot module replacement with Vite integration for seamless development experience

## Data Storage Solutions
- **Database**: PostgreSQL with Drizzle ORM for type-safe database operations
- **Schema Design**: Modular tables for users, products, orders, order items, user library, and wishlist
- **Connection**: Neon Database serverless PostgreSQL for cloud hosting
- **Migrations**: Drizzle Kit for database schema management and migrations
- **Storage Interface**: Abstract storage interface allowing for easy database provider switching

## Authentication and Authorization
- **Session Management**: Express sessions with PostgreSQL session storage using connect-pg-simple
- **User Roles**: Basic role-based access control with admin flag for administrative functions
- **Security**: Password hashing and secure session handling (implementation details not fully visible in current codebase)

## External Dependencies
- **Database**: Neon Database (@neondatabase/serverless) for serverless PostgreSQL
- **UI Components**: Extensive use of Radix UI primitives for accessible component foundation
- **Form Handling**: React Hook Form with Hookform Resolvers for form validation
- **Date Handling**: date-fns for date manipulation and formatting
- **Development Tools**: Replit-specific plugins for development environment integration
- **Build Tools**: esbuild for server bundling, Vite for client bundling

The architecture follows a clear separation of concerns with the frontend handling user interactions and state management, while the backend focuses on data processing and API endpoints. The shared schema folder provides type safety across the full stack, ensuring consistency between frontend and backend data structures.