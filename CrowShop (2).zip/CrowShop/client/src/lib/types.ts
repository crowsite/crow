export interface CartItem {
  id: string;
  title: string;
  price: string;
  imageUrl: string;
  quantity: number;
}

export interface CartState {
  items: CartItem[];
  total: number;
  itemCount: number;
}

export interface StorageStats {
  total: string;
  used: string;
  cloud: string;
  games: string;
  screenshots: string;
  videos: string;
}

export interface AdminStats {
  totalUsers: number;
  salesToday: number;
  gamesCount: number;
  downloads: number;
}
