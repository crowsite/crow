import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Play, Star, Users, Shield, Gamepad2, Mail, Lock, Eye, EyeOff } from "lucide-react";

export default function Landing() {
  const [isLoginOpen, setIsLoginOpen] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [loginForm, setLoginForm] = useState({ email: "", password: "" });
  const [signupForm, setSignupForm] = useState({ email: "", password: "", confirmPassword: "", firstName: "", lastName: "" });

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    // Handle login logic here
    console.log("Login:", loginForm);
  };

  const handleSignup = (e: React.FormEvent) => {
    e.preventDefault();
    // Handle signup logic here
    console.log("Signup:", signupForm);
  };

  const handleGoogleLogin = () => {
    window.location.href = '/api/login';
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-black via-gray-900 to-black text-white overflow-hidden">
      {/* Animated crow silhouette background */}
      <div className="fixed inset-0 opacity-5 pointer-events-none">
        <div className="absolute top-10 left-10 animate-float">
          <svg width="100" height="100" viewBox="0 0 100 100" fill="currentColor">
            <path d="M20 70c0-10 5-15 15-15s15 5 15 15-5 15-15 15-15-5-15-15zM35 50c5-5 10-5 15 0s5 10 0 15-10 5-15 0-5-10 0-15zM60 40c0-5 2-8 8-8s8 3 8 8-2 8-8 8-8-3-8-8z"/>
          </svg>
        </div>
        <div className="absolute top-40 right-20 animate-float" style={{ animationDelay: '2s' }}>
          <svg width="80" height="80" viewBox="0 0 100 100" fill="currentColor">
            <path d="M30 60c0-8 4-12 12-12s12 4 12 12-4 12-12 12-12-4-12-12zM45 45c4-4 8-4 12 0s4 8 0 12-8 4-12 0-4-8 0-12z"/>
          </svg>
        </div>
        <div className="absolute bottom-20 left-1/3 animate-float" style={{ animationDelay: '4s' }}>
          <svg width="120" height="120" viewBox="0 0 100 100" fill="currentColor">
            <path d="M25 65c0-12 6-18 18-18s18 6 18 18-6 18-18 18-18-6-18-18zM40 45c6-6 12-6 18 0s6 12 0 18-12 6-18 0-6-12 0-18z"/>
          </svg>
        </div>
      </div>

      {/* Navigation */}
      <nav className="relative z-50 border-b border-gray-800 backdrop-blur-md bg-black/40 sticky top-0">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-4">
              <Gamepad2 className="h-8 w-8 text-cyan-400 animate-pulse" />
              <h1 className="text-2xl font-black text-white tracking-wider">Crow Site</h1>
            </div>
            <div className="flex items-center space-x-4">
              <Dialog open={isLoginOpen} onOpenChange={setIsLoginOpen}>
                <DialogTrigger asChild>
                  <Button className="bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-600 hover:to-blue-700 text-black font-black px-6 py-2 rounded-lg shadow-lg hover:shadow-cyan-500/25 transition-all duration-300 transform hover:scale-105">
                    ورود / ثبت نام
                  </Button>
                </DialogTrigger>
                <DialogContent className="bg-gray-900 border-gray-700 max-w-md">
                  <DialogHeader>
                    <DialogTitle className="text-white font-black text-center text-xl">
                      به Crow Site خوش آمدید
                    </DialogTitle>
                  </DialogHeader>
                  
                  <Tabs defaultValue="login" className="w-full">
                    <TabsList className="grid w-full grid-cols-2 bg-gray-800">
                      <TabsTrigger value="login" className="text-white font-bold data-[state=active]:bg-cyan-600">ورود</TabsTrigger>
                      <TabsTrigger value="signup" className="text-white font-bold data-[state=active]:bg-cyan-600">ثبت نام</TabsTrigger>
                    </TabsList>
                    
                    <TabsContent value="login" className="space-y-4">
                      <form onSubmit={handleLogin} className="space-y-4">
                        <div>
                          <Label htmlFor="email" className="text-white font-bold">ایمیل</Label>
                          <div className="relative">
                            <Mail className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                            <Input
                              id="email"
                              type="email"
                              value={loginForm.email}
                              onChange={(e) => setLoginForm({ ...loginForm, email: e.target.value })}
                              className="pl-10 bg-gray-800 border-gray-600 text-white font-bold"
                              placeholder="ایمیل خود را وارد کنید"
                              required
                            />
                          </div>
                        </div>
                        <div>
                          <Label htmlFor="password" className="text-white font-bold">رمز عبور</Label>
                          <div className="relative">
                            <Lock className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                            <Input
                              id="password"
                              type={showPassword ? "text" : "password"}
                              value={loginForm.password}
                              onChange={(e) => setLoginForm({ ...loginForm, password: e.target.value })}
                              className="pl-10 pr-10 bg-gray-800 border-gray-600 text-white font-bold"
                              placeholder="رمز عبور خود را وارد کنید"
                              required
                            />
                            <button
                              type="button"
                              onClick={() => setShowPassword(!showPassword)}
                              className="absolute right-3 top-3 text-gray-400 hover:text-white"
                            >
                              {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                            </button>
                          </div>
                        </div>
                        <Button type="submit" className="w-full bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-600 hover:to-blue-700 text-black font-black">
                          ورود
                        </Button>
                      </form>
                      
                      <div className="relative">
                        <div className="absolute inset-0 flex items-center">
                          <span className="w-full border-t border-gray-600" />
                        </div>
                        <div className="relative flex justify-center text-xs uppercase">
                          <span className="bg-gray-900 px-2 text-gray-400 font-bold">یا</span>
                        </div>
                      </div>
                      
                      <Button 
                        onClick={handleGoogleLogin}
                        type="button" 
                        variant="outline" 
                        className="w-full border-gray-600 text-white hover:bg-gray-800 font-bold"
                      >
                        <svg className="w-4 h-4 mr-2" viewBox="0 0 24 24">
                          <path fill="currentColor" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
                          <path fill="currentColor" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
                          <path fill="currentColor" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/>
                          <path fill="currentColor" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/>
                        </svg>
                        ورود با Google
                      </Button>
                    </TabsContent>
                    
                    <TabsContent value="signup" className="space-y-4">
                      <form onSubmit={handleSignup} className="space-y-4">
                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <Label htmlFor="firstName" className="text-white font-bold">نام</Label>
                            <Input
                              id="firstName"
                              value={signupForm.firstName}
                              onChange={(e) => setSignupForm({ ...signupForm, firstName: e.target.value })}
                              className="bg-gray-800 border-gray-600 text-white font-bold"
                              placeholder="نام"
                              required
                            />
                          </div>
                          <div>
                            <Label htmlFor="lastName" className="text-white font-bold">نام خانوادگی</Label>
                            <Input
                              id="lastName"
                              value={signupForm.lastName}
                              onChange={(e) => setSignupForm({ ...signupForm, lastName: e.target.value })}
                              className="bg-gray-800 border-gray-600 text-white font-bold"
                              placeholder="نام خانوادگی"
                              required
                            />
                          </div>
                        </div>
                        <div>
                          <Label htmlFor="signup-email" className="text-white font-bold">ایمیل</Label>
                          <div className="relative">
                            <Mail className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                            <Input
                              id="signup-email"
                              type="email"
                              value={signupForm.email}
                              onChange={(e) => setSignupForm({ ...signupForm, email: e.target.value })}
                              className="pl-10 bg-gray-800 border-gray-600 text-white font-bold"
                              placeholder="ایمیل خود را وارد کنید"
                              required
                            />
                          </div>
                        </div>
                        <div>
                          <Label htmlFor="signup-password" className="text-white font-bold">رمز عبور</Label>
                          <div className="relative">
                            <Lock className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                            <Input
                              id="signup-password"
                              type={showPassword ? "text" : "password"}
                              value={signupForm.password}
                              onChange={(e) => setSignupForm({ ...signupForm, password: e.target.value })}
                              className="pl-10 pr-10 bg-gray-800 border-gray-600 text-white font-bold"
                              placeholder="رمز عبور خود را وارد کنید"
                              required
                            />
                            <button
                              type="button"
                              onClick={() => setShowPassword(!showPassword)}
                              className="absolute right-3 top-3 text-gray-400 hover:text-white"
                            >
                              {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                            </button>
                          </div>
                        </div>
                        <div>
                          <Label htmlFor="confirm-password" className="text-white font-bold">تکرار رمز عبور</Label>
                          <div className="relative">
                            <Lock className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                            <Input
                              id="confirm-password"
                              type={showPassword ? "text" : "password"}
                              value={signupForm.confirmPassword}
                              onChange={(e) => setSignupForm({ ...signupForm, confirmPassword: e.target.value })}
                              className="pl-10 bg-gray-800 border-gray-600 text-white font-bold"
                              placeholder="رمز عبور را دوباره وارد کنید"
                              required
                            />
                          </div>
                        </div>
                        <Button type="submit" className="w-full bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-600 hover:to-blue-700 text-black font-black">
                          ثبت نام
                        </Button>
                      </form>
                      
                      <div className="relative">
                        <div className="absolute inset-0 flex items-center">
                          <span className="w-full border-t border-gray-600" />
                        </div>
                        <div className="relative flex justify-center text-xs uppercase">
                          <span className="bg-gray-900 px-2 text-gray-400 font-bold">یا</span>
                        </div>
                      </div>
                      
                      <Button 
                        onClick={handleGoogleLogin}
                        type="button" 
                        variant="outline" 
                        className="w-full border-gray-600 text-white hover:bg-gray-800 font-bold"
                      >
                        <svg className="w-4 h-4 mr-2" viewBox="0 0 24 24">
                          <path fill="currentColor" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
                          <path fill="currentColor" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
                          <path fill="currentColor" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/>
                          <path fill="currentColor" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/>
                        </svg>
                        ثبت نام با Google
                      </Button>
                    </TabsContent>
                  </Tabs>
                </DialogContent>
              </Dialog>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative py-20 px-4 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-cyan-900/20 via-purple-900/10 to-orange-900/20"></div>
        <div className="max-w-7xl mx-auto text-center relative z-10">
          <div className="animate-fade-in">
            <h1 className="text-6xl md:text-8xl font-black mb-6 bg-gradient-to-r from-cyan-400 via-purple-400 to-orange-400 bg-clip-text text-transparent animate-pulse">
              فروشگاه دیجیتال گیمینگ
            </h1>
            <p className="text-2xl md:text-3xl text-gray-300 mb-8 max-w-4xl mx-auto font-black leading-relaxed">
              بهترین بازی‌های دیجیتال را با بهترین قیمت‌ها و کیفیت‌ترین سرویس دریافت کنید
            </p>
            <div className="flex flex-col sm:flex-row gap-6 justify-center items-center mt-12">
              <Button 
                onClick={() => setIsLoginOpen(true)}
                size="lg" 
                className="bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-600 hover:to-blue-700 text-black font-black px-12 py-6 text-xl rounded-xl shadow-lg hover:shadow-cyan-500/25 transition-all duration-300 transform hover:scale-105"
              >
                <Play className="mr-3 h-6 w-6" />
                شروع کنید
              </Button>
              <Button 
                variant="outline" 
                size="lg"
                className="border-2 border-cyan-400 text-cyan-400 hover:bg-cyan-400 hover:text-black font-black px-12 py-6 text-xl rounded-xl transition-all duration-300 transform hover:scale-105"
              >
                کاوش بازی‌ها
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Three-line menu section */}
      <section className="py-16 px-4 bg-black/50 backdrop-blur-sm border-y border-gray-800">
        <div className="max-w-7xl mx-auto">
          <div className="grid md:grid-cols-3 gap-8 text-center">
            <div className="group p-8 bg-gradient-to-br from-gray-900/80 to-black/80 rounded-2xl border border-gray-800 hover:border-cyan-500 transition-all duration-500 transform hover:scale-105 hover:shadow-2xl hover:shadow-cyan-500/20">
              <div className="bg-gradient-to-br from-cyan-500 to-blue-600 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-6 group-hover:animate-pulse">
                <Star className="h-8 w-8 text-black" />
              </div>
              <h3 className="text-2xl font-black mb-4 text-white group-hover:text-cyan-400 transition-colors">بهترین کیفیت</h3>
              <p className="text-gray-400 font-bold text-lg leading-relaxed">بازی‌های اورجینال با بهترین کیفیت و قیمت مناسب در بازار</p>
            </div>
            <div className="group p-8 bg-gradient-to-br from-gray-900/80 to-black/80 rounded-2xl border border-gray-800 hover:border-purple-500 transition-all duration-500 transform hover:scale-105 hover:shadow-2xl hover:shadow-purple-500/20">
              <div className="bg-gradient-to-br from-purple-500 to-pink-600 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-6 group-hover:animate-pulse">
                <Shield className="h-8 w-8 text-black" />
              </div>
              <h3 className="text-2xl font-black mb-4 text-white group-hover:text-purple-400 transition-colors">امنیت بالا</h3>
              <p className="text-gray-400 font-bold text-lg leading-relaxed">خرید امن با گارانتی و پشتیبانی ۲۴ ساعته برای همه کاربران</p>
            </div>
            <div className="group p-8 bg-gradient-to-br from-gray-900/80 to-black/80 rounded-2xl border border-gray-800 hover:border-orange-500 transition-all duration-500 transform hover:scale-105 hover:shadow-2xl hover:shadow-orange-500/20">
              <div className="bg-gradient-to-br from-orange-500 to-red-600 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-6 group-hover:animate-pulse">
                <Users className="h-8 w-8 text-black" />
              </div>
              <h3 className="text-2xl font-black mb-4 text-white group-hover:text-orange-400 transition-colors">جامعه گیمرها</h3>
              <p className="text-gray-400 font-bold text-lg leading-relaxed">عضویت در بزرگترین جامعه گیمرهای ایران با هزاران کاربر فعال</p>
            </div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-20 px-4 bg-gradient-to-r from-gray-900/50 to-black/50">
        <div className="max-w-7xl mx-auto">
          <div className="grid md:grid-cols-4 gap-8 text-center">
            <div className="transform hover:scale-110 transition-all duration-300">
              <div className="text-5xl font-black text-cyan-400 mb-2 animate-pulse">1000+</div>
              <div className="text-gray-400 font-bold text-xl">بازی موجود</div>
            </div>
            <div className="transform hover:scale-110 transition-all duration-300">
              <div className="text-5xl font-black text-purple-400 mb-2 animate-pulse">50K+</div>
              <div className="text-gray-400 font-bold text-xl">کاربر فعال</div>
            </div>
            <div className="transform hover:scale-110 transition-all duration-300">
              <div className="text-5xl font-black text-orange-400 mb-2 animate-pulse">99%</div>
              <div className="text-gray-400 font-bold text-xl">رضایت مشتری</div>
            </div>
            <div className="transform hover:scale-110 transition-all duration-300">
              <div className="text-5xl font-black text-green-400 mb-2 animate-pulse">24/7</div>
              <div className="text-gray-400 font-bold text-xl">پشتیبانی</div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-4 bg-gradient-to-r from-cyan-900/30 to-purple-900/30 border-t border-gray-800">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-5xl font-black mb-6 text-white">آماده برای شروع هستید؟</h2>
          <p className="text-2xl text-gray-300 mb-8 font-black leading-relaxed">
            به بزرگترین فروشگاه دیجیتال گیمینگ ایران بپیوندید
          </p>
          <Button 
            onClick={() => setIsLoginOpen(true)}
            size="lg" 
            className="bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-600 hover:to-blue-700 text-black font-black px-16 py-6 text-2xl rounded-xl shadow-lg hover:shadow-cyan-500/25 transition-all duration-300 transform hover:scale-105"
          >
            همین الان شروع کنید
          </Button>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-gray-800 py-12 px-4 bg-black/80">
        <div className="max-w-7xl mx-auto text-center">
          <div className="flex items-center justify-center space-x-4 mb-6">
            <Gamepad2 className="h-10 w-10 text-cyan-400" />
            <h3 className="text-3xl font-black text-white">Crow Site</h3>
          </div>
          <p className="text-gray-400 font-bold text-lg mb-6">
            فروشگاه دیجیتال گیمینگ با کیفیت و امنیت بالا
          </p>
          <div className="mt-8 text-sm text-gray-500 font-bold">
            © 2024 Crow Site. تمامی حقوق محفوظ است.
          </div>
        </div>
      </footer>
    </div>
  );
}