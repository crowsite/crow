import { useState } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { isUnauthorizedError } from "@/lib/authUtils";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Separator } from "@/components/ui/separator";
import { User, Edit, Save, LogOut, Camera } from "lucide-react";
import { useEffect } from "react";

export default function Profile() {
  const { user, isLoading, isAuthenticated } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isEditing, setIsEditing] = useState(false);
  const [formData, setFormData] = useState({
    firstName: "",
    lastName: "",
    bio: "",
    phoneNumber: "",
  });

  // Redirect to home if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "غیر مجاز",
        description: "شما وارد نشده‌اید. در حال هدایت به صفحه ورود...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  useEffect(() => {
    if (user) {
      setFormData({
        firstName: user.firstName || "",
        lastName: user.lastName || "",
        bio: user.bio || "",
        phoneNumber: user.phoneNumber || "",
      });
    }
  }, [user]);

  const updateProfileMutation = useMutation({
    mutationFn: async (updates: any) => {
      await apiRequest("/api/auth/user", {
        method: "PATCH",
        body: JSON.stringify(updates),
        headers: {
          "Content-Type": "application/json",
        },
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/auth/user"] });
      setIsEditing(false);
      toast({
        title: "موفقیت",
        description: "پروفایل شما با موفقیت به‌روزرسانی شد",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "غیر مجاز",
          description: "شما وارد نشده‌اید. در حال هدایت به صفحه ورود...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "خطا",
        description: "خطا در به‌روزرسانی پروفایل",
        variant: "destructive",
      });
    },
  });

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-crow-black via-crow-gray to-crow-black flex items-center justify-center">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-neon-cyan"></div>
      </div>
    );
  }

  if (!user) {
    return null;
  }

  const handleSave = () => {
    updateProfileMutation.mutate(formData);
  };

  const handleLogout = () => {
    window.location.href = "/api/logout";
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-crow-black via-crow-gray to-crow-black py-8 px-4">
      <div className="max-w-4xl mx-auto">
        <div className="flex items-center justify-between mb-8">
          <h1 className="text-4xl font-black text-white">پروفایل کاربری</h1>
          <Button 
            onClick={handleLogout}
            variant="outline"
            className="border-red-500 text-red-500 hover:bg-red-500 hover:text-white font-bold"
          >
            <LogOut className="mr-2 h-4 w-4" />
            خروج
          </Button>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Profile Picture and Basic Info */}
          <Card className="lg:col-span-1 bg-gray-900 border-gray-800">
            <CardHeader className="text-center">
              <div className="relative mx-auto w-32 h-32 mb-4">
                <Avatar className="w-32 h-32">
                  <AvatarImage src={user.profileImageUrl || ""} alt="پروفایل" />
                  <AvatarFallback className="bg-neon-cyan text-black text-2xl font-black">
                    {user.firstName?.[0] || user.email?.[0] || "کاربر"}
                  </AvatarFallback>
                </Avatar>
                <Button
                  size="sm"
                  className="absolute bottom-0 right-0 rounded-full bg-neon-cyan hover:bg-cyan-600 text-black"
                >
                  <Camera className="h-4 w-4" />
                </Button>
              </div>
              <CardTitle className="text-white font-black">
                {user.firstName && user.lastName 
                  ? `${user.firstName} ${user.lastName}`
                  : user.email
                }
              </CardTitle>
              <CardDescription className="text-gray-400 font-bold">
                {user.email}
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="text-center">
                  <p className="text-sm text-gray-500 font-bold">عضو از</p>
                  <p className="text-white font-bold">
                    {new Date(user.createdAt!).toLocaleDateString('fa-IR')}
                  </p>
                </div>
                {user.isAdmin && (
                  <div className="bg-gaming-orange/20 border border-gaming-orange rounded-lg p-3 text-center">
                    <p className="text-gaming-orange font-black">مدیر سایت</p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Profile Details */}
          <Card className="lg:col-span-2 bg-gray-900 border-gray-800">
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle className="text-white font-black">اطلاعات شخصی</CardTitle>
                <CardDescription className="text-gray-400 font-bold">
                  اطلاعات حساب کاربری خود را ویرایش کنید
                </CardDescription>
              </div>
              <Button
                onClick={() => isEditing ? handleSave() : setIsEditing(true)}
                disabled={updateProfileMutation.isPending}
                className="bg-neon-cyan hover:bg-cyan-600 text-black font-bold"
              >
                {isEditing ? (
                  <>
                    <Save className="mr-2 h-4 w-4" />
                    ذخیره
                  </>
                ) : (
                  <>
                    <Edit className="mr-2 h-4 w-4" />
                    ویرایش
                  </>
                )}
              </Button>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="firstName" className="text-white font-bold">نام</Label>
                  <Input
                    id="firstName"
                    value={formData.firstName}
                    onChange={(e) => setFormData({ ...formData, firstName: e.target.value })}
                    disabled={!isEditing}
                    className="bg-gray-800 border-gray-700 text-white font-bold mt-1"
                    placeholder="نام خود را وارد کنید"
                  />
                </div>
                <div>
                  <Label htmlFor="lastName" className="text-white font-bold">نام خانوادگی</Label>
                  <Input
                    id="lastName"
                    value={formData.lastName}
                    onChange={(e) => setFormData({ ...formData, lastName: e.target.value })}
                    disabled={!isEditing}
                    className="bg-gray-800 border-gray-700 text-white font-bold mt-1"
                    placeholder="نام خانوادگی خود را وارد کنید"
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="phoneNumber" className="text-white font-bold">شماره تلفن</Label>
                <Input
                  id="phoneNumber"
                  value={formData.phoneNumber}
                  onChange={(e) => setFormData({ ...formData, phoneNumber: e.target.value })}
                  disabled={!isEditing}
                  className="bg-gray-800 border-gray-700 text-white font-bold mt-1"
                  placeholder="شماره تلفن خود را وارد کنید"
                />
              </div>

              <div>
                <Label htmlFor="bio" className="text-white font-bold">درباره من</Label>
                <Textarea
                  id="bio"
                  value={formData.bio}
                  onChange={(e) => setFormData({ ...formData, bio: e.target.value })}
                  disabled={!isEditing}
                  className="bg-gray-800 border-gray-700 text-white font-bold mt-1"
                  placeholder="چیزی درباره خودتان بنویسید..."
                  rows={4}
                />
              </div>

              <Separator className="bg-gray-700" />

              <div>
                <Label className="text-white font-bold">ایمیل</Label>
                <Input
                  value={user.email || ""}
                  disabled
                  className="bg-gray-800 border-gray-700 text-gray-400 font-bold mt-1"
                />
                <p className="text-sm text-gray-500 mt-1 font-bold">ایمیل قابل تغییر نیست</p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}