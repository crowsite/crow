import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Navigation } from '@/components/layout/navigation';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ShoppingCart, Star, Download, Play, Users, Trophy, Gamepad2 } from 'lucide-react';
import { useCart } from '@/hooks/use-cart';
import type { Product } from '@shared/schema';

export default function Home() {
  const [activeFilter, setActiveFilter] = useState('all');
  const { addToCart } = useCart();

  // Sample products data
  const sampleProducts = [
    { 
      id: 1, 
      name: "Cyberpunk 2077", 
      description: "بازی نقش‌آفرینی فوق‌العاده در آینده", 
      price: 59.99, 
      category: "RPG", 
      imageUrl: "https://via.placeholder.com/400x300/0ea5e9/000000?text=Cyberpunk+2077",
      rating: 4.5,
      downloads: 50000
    },
    { 
      id: 2, 
      name: "Call of Duty: MW3", 
      description: "بازی اکشن و تیراندازی حماسی", 
      price: 69.99, 
      category: "Action", 
      imageUrl: "https://via.placeholder.com/400x300/8b5cf6/000000?text=Call+of+Duty",
      rating: 4.8,
      downloads: 75000
    },
    { 
      id: 3, 
      name: "FIFA 24", 
      description: "شبیه‌ساز فوتبال پیشرفته", 
      price: 59.99, 
      category: "Sports", 
      imageUrl: "https://via.placeholder.com/400x300/f97316/000000?text=FIFA+24",
      rating: 4.3,
      downloads: 40000
    },
    { 
      id: 4, 
      name: "Assassin's Creed Mirage", 
      description: "ماجراجویی در خاورمیانه باستان", 
      price: 49.99, 
      category: "Adventure", 
      imageUrl: "https://via.placeholder.com/400x300/22c55e/000000?text=AC+Mirage",
      rating: 4.6,
      downloads: 60000
    },
    { 
      id: 5, 
      name: "Spider-Man 2", 
      description: "بازی ابرقهرمانی شگفت‌انگیز", 
      price: 69.99, 
      category: "Action", 
      imageUrl: "https://via.placeholder.com/400x300/dc2626/000000?text=Spider-Man+2",
      rating: 4.9,
      downloads: 80000
    },
    { 
      id: 6, 
      name: "The Witcher 3", 
      description: "بازی نقش‌آفرینی افسانه‌ای", 
      price: 39.99, 
      category: "RPG", 
      imageUrl: "https://via.placeholder.com/400x300/6366f1/000000?text=Witcher+3",
      rating: 4.7,
      downloads: 90000
    }
  ];

  const filteredProducts = activeFilter === 'all' 
    ? sampleProducts 
    : sampleProducts.filter(product => product.category === activeFilter);

  const categories = ['all', 'Action', 'RPG', 'Sports', 'Adventure'];

  return (
    <div className="min-h-screen bg-gradient-to-br from-black via-gray-900 to-black text-white">
      <Navigation />
      
      {/* Hero Section */}
      <section id="home" className="pt-20 pb-16 px-4 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-cyan-900/20 via-purple-900/10 to-orange-900/20"></div>
        <div className="max-w-7xl mx-auto text-center relative z-10">
          <div className="animate-fade-in">
            <h1 className="text-6xl md:text-8xl font-black mb-6 bg-gradient-to-r from-cyan-400 via-purple-400 to-orange-400 bg-clip-text text-transparent">
              فروشگاه گیمینگ
            </h1>
            <p className="text-2xl md:text-3xl text-gray-300 mb-8 max-w-4xl mx-auto font-bold">
              بهترین بازی‌های دیجیتال را با بهترین قیمت‌ها دریافت کنید
            </p>
            <div className="flex flex-col sm:flex-row gap-6 justify-center items-center">
              <Button 
                onClick={() => document.getElementById('games')?.scrollIntoView({ behavior: 'smooth' })}
                size="lg" 
                className="bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-600 hover:to-blue-700 text-black font-black px-12 py-6 text-xl rounded-xl shadow-lg hover:shadow-cyan-500/25 transition-all duration-300 transform hover:scale-105"
              >
                <Play className="mr-3 h-6 w-6" />
                مشاهده بازی‌ها
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Three-line features section */}
      <section className="py-16 px-4 bg-black/50 backdrop-blur-sm border-y border-gray-800">
        <div className="max-w-7xl mx-auto">
          <div className="grid md:grid-cols-3 gap-8 text-center">
            <div className="group p-8 bg-gradient-to-br from-gray-900/80 to-black/80 rounded-2xl border border-gray-800 hover:border-cyan-500 transition-all duration-500 transform hover:scale-105 hover:shadow-2xl hover:shadow-cyan-500/20">
              <div className="bg-gradient-to-br from-cyan-500 to-blue-600 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-6 group-hover:animate-pulse">
                <Star className="h-8 w-8 text-black" />
              </div>
              <h3 className="text-2xl font-black mb-4 text-white group-hover:text-cyan-400 transition-colors">بهترین کیفیت</h3>
              <p className="text-gray-400 font-bold text-lg">بازی‌های اورجینال با بهترین کیفیت و قیمت مناسب</p>
            </div>
            <div className="group p-8 bg-gradient-to-br from-gray-900/80 to-black/80 rounded-2xl border border-gray-800 hover:border-purple-500 transition-all duration-500 transform hover:scale-105 hover:shadow-2xl hover:shadow-purple-500/20">
              <div className="bg-gradient-to-br from-purple-500 to-pink-600 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-6 group-hover:animate-pulse">
                <Download className="h-8 w-8 text-black" />
              </div>
              <h3 className="text-2xl font-black mb-4 text-white group-hover:text-purple-400 transition-colors">دانلود فوری</h3>
              <p className="text-gray-400 font-bold text-lg">دانلود فوری پس از خرید با لینک مستقیم</p>
            </div>
            <div className="group p-8 bg-gradient-to-br from-gray-900/80 to-black/80 rounded-2xl border border-gray-800 hover:border-orange-500 transition-all duration-500 transform hover:scale-105 hover:shadow-2xl hover:shadow-orange-500/20">
              <div className="bg-gradient-to-br from-orange-500 to-red-600 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-6 group-hover:animate-pulse">
                <Users className="h-8 w-8 text-black" />
              </div>
              <h3 className="text-2xl font-black mb-4 text-white group-hover:text-orange-400 transition-colors">پشتیبانی ۲۴/۷</h3>
              <p className="text-gray-400 font-bold text-lg">پشتیبانی کامل در تمام ساعات شبانه‌روز</p>
            </div>
          </div>
        </div>
      </section>
      
      {/* Games Section */}
      <section id="games" className="py-20 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-5xl font-black text-white mb-4">
              مجموعه بازی‌ها
            </h2>
            <p className="text-xl text-gray-300 max-w-2xl mx-auto font-bold">
              جدیدترین و بهترین بازی‌ها در تمام ژانرها را کشف کنید
            </p>
          </div>
          
          {/* Category Filters */}
          <div className="flex justify-center mb-12">
            <div className="flex flex-wrap gap-4 p-2 bg-gray-800/50 rounded-xl backdrop-blur-sm">
              {categories.map((category) => (
                <Button
                  key={category}
                  onClick={() => setActiveFilter(category)}
                  variant={activeFilter === category ? "default" : "ghost"}
                  className={`font-bold transition-all duration-300 ${
                    activeFilter === category 
                      ? "bg-gradient-to-r from-cyan-500 to-blue-600 text-black" 
                      : "text-white hover:text-cyan-400"
                  }`}
                >
                  {category === 'all' ? 'همه' : category}
                </Button>
              ))}
            </div>
          </div>
          
          {/* Games Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredProducts.map((product, index) => (
              <Card 
                key={product.id} 
                className="bg-gradient-to-br from-gray-900/80 to-black/80 border-gray-800 hover:border-cyan-500 transition-all duration-500 transform hover:scale-105 hover:shadow-2xl hover:shadow-cyan-500/20 group overflow-hidden"
                style={{ animationDelay: `${index * 100}ms` }}
              >
                <div className="relative overflow-hidden">
                  <img 
                    src={product.imageUrl} 
                    alt={product.name}
                    className="w-full h-48 object-cover group-hover:scale-110 transition-transform duration-500"
                  />
                  <div className="absolute top-4 right-4">
                    <Badge className="bg-yellow-500 text-black font-bold">
                      <Star className="h-3 w-3 mr-1" />
                      {product.rating}
                    </Badge>
                  </div>
                  <div className="absolute bottom-4 left-4">
                    <Badge variant="secondary" className="bg-gray-800/80 text-white font-bold">
                      <Download className="h-3 w-3 mr-1" />
                      {product.downloads.toLocaleString()}
                    </Badge>
                  </div>
                </div>
                <CardHeader>
                  <CardTitle className="text-white font-black text-xl group-hover:text-cyan-400 transition-colors">
                    {product.name}
                  </CardTitle>
                  <CardDescription className="text-gray-400 font-bold">
                    {product.description}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center justify-between mb-4">
                    <div className="text-2xl font-black text-cyan-400">
                      ${product.price}
                    </div>
                    <Badge variant="outline" className="border-gray-600 text-gray-300">
                      {product.category}
                    </Badge>
                  </div>
                  <Button 
                    onClick={() => addToCart(product)}
                    className="w-full bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-600 hover:to-blue-700 text-black font-black transition-all duration-300 transform hover:scale-105"
                  >
                    <ShoppingCart className="h-4 w-4 mr-2" />
                    افزودن به سبد خرید
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Storage Management Section */}
      <section id="storage" className="py-20 px-4 bg-gradient-to-r from-gray-900/50 to-black/50 border-t border-gray-800">
        <div className="max-w-7xl mx-auto text-center">
          <h2 className="text-4xl font-black text-white mb-6">مدیریت حافظه هوشمند</h2>
          <p className="text-xl text-gray-300 mb-12 max-w-3xl mx-auto font-bold">
            سیستم مدیریت حافظه پیشرفته برای بهینه‌سازی فضای ذخیره‌سازی شما
          </p>
          
          <div className="grid md:grid-cols-2 gap-8 mb-12">
            <Card className="bg-gradient-to-br from-gray-900/80 to-black/80 border-gray-800">
              <CardHeader>
                <CardTitle className="text-white font-black text-xl flex items-center justify-center">
                  <Trophy className="h-6 w-6 mr-2 text-yellow-400" />
                  فضای استفاده شده
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-4xl font-black text-cyan-400 mb-2">245 GB</div>
                <p className="text-gray-400 font-bold">از 500 GB</p>
                <div className="w-full bg-gray-700 rounded-full h-3 mt-4">
                  <div className="bg-gradient-to-r from-cyan-500 to-blue-600 h-3 rounded-full" style={{ width: '49%' }}></div>
                </div>
              </CardContent>
            </Card>
            
            <Card className="bg-gradient-to-br from-gray-900/80 to-black/80 border-gray-800">
              <CardHeader>
                <CardTitle className="text-white font-black text-xl flex items-center justify-center">
                  <Gamepad2 className="h-6 w-6 mr-2 text-purple-400" />
                  بازی‌های نصب شده
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-4xl font-black text-purple-400 mb-2">12</div>
                <p className="text-gray-400 font-bold">بازی فعال</p>
              </CardContent>
            </Card>
          </div>
          
          <Button className="bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-600 hover:to-blue-700 text-black font-black px-8 py-4 text-lg rounded-xl">
            مدیریت فضای ذخیره‌سازی
          </Button>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-gray-800 py-12 px-4 bg-black/80">
        <div className="max-w-7xl mx-auto text-center">
          <div className="flex items-center justify-center space-x-4 mb-6">
            <Gamepad2 className="h-10 w-10 text-cyan-400" />
            <h3 className="text-3xl font-black text-white">Crow Site</h3>
          </div>
          <p className="text-gray-400 font-bold text-lg mb-6">
            فروشگاه دیجیتال گیمینگ با کیفیت و امنیت بالا
          </p>
          <div className="grid md:grid-cols-3 gap-8 mb-8">
            <div>
              <h4 className="text-white font-black mb-4">لینک‌های مفید</h4>
              <div className="space-y-2">
                <p className="text-gray-400 font-bold cursor-pointer hover:text-cyan-400 transition-colors">درباره ما</p>
                <p className="text-gray-400 font-bold cursor-pointer hover:text-cyan-400 transition-colors">تماس با ما</p>
                <p className="text-gray-400 font-bold cursor-pointer hover:text-cyan-400 transition-colors">قوانین و مقررات</p>
              </div>
            </div>
            <div>
              <h4 className="text-white font-black mb-4">خدمات</h4>
              <div className="space-y-2">
                <p className="text-gray-400 font-bold cursor-pointer hover:text-cyan-400 transition-colors">پشتیبانی فنی</p>
                <p className="text-gray-400 font-bold cursor-pointer hover:text-cyan-400 transition-colors">راهنمای خرید</p>
                <p className="text-gray-400 font-bold cursor-pointer hover:text-cyan-400 transition-colors">سیستم امتیازات</p>
              </div>
            </div>
            <div>
              <h4 className="text-white font-black mb-4">شبکه‌های اجتماعی</h4>
              <div className="space-y-2">
                <p className="text-gray-400 font-bold cursor-pointer hover:text-cyan-400 transition-colors">تلگرام</p>
                <p className="text-gray-400 font-bold cursor-pointer hover:text-cyan-400 transition-colors">اینستاگرام</p>
                <p className="text-gray-400 font-bold cursor-pointer hover:text-cyan-400 transition-colors">یوتیوب</p>
              </div>
            </div>
          </div>
          <div className="text-sm text-gray-500 font-bold">
            © 2024 Crow Site. تمامی حقوق محفوظ است.
          </div>
        </div>
      </footer>
    </div>
  );
}
