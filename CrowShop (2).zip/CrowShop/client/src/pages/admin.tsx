import { useState, useEffect } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { 
  Star, 
  Plus, 
  Edit, 
  Trash2, 
  Users, 
  Package, 
  DollarSign, 
  TrendingUp,
  Shield,
  Settings,
  GamepadIcon
} from "lucide-react";

export default function Admin() {
  const { user, isLoading, isAuthenticated } = useAuth();
  const { toast } = useToast();
  const [adminPassword, setAdminPassword] = useState("");
  const [isAdminVerified, setIsAdminVerified] = useState(false);
  const [showPasswordDialog, setShowPasswordDialog] = useState(true);

  // Check if user should have admin access
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "غیر مجاز",
        description: "ابتدا وارد حساب کاربری خود شوید",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/";
      }, 1000);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  const handleAdminPasswordSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (adminPassword === "615780") {
      setIsAdminVerified(true);
      setShowPasswordDialog(false);
      toast({
        title: "موفقیت",
        description: "شما به عنوان مدیر وارد شدید",
      });
    } else {
      toast({
        title: "خطا",
        description: "رمز عبور مدیریت اشتباه است",
        variant: "destructive",
      });
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-black via-gray-900 to-black flex items-center justify-center">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-cyan-400"></div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return null;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-black via-gray-900 to-black text-white">
      {/* Admin Password Dialog */}
      <Dialog open={showPasswordDialog && !isAdminVerified} onOpenChange={setShowPasswordDialog}>
        <DialogContent className="bg-gray-900 border-gray-700">
          <DialogHeader>
            <DialogTitle className="text-white font-black text-center text-xl flex items-center justify-center">
              <Shield className="mr-2 h-6 w-6 text-cyan-400" />
              ورود به پنل مدیریت
            </DialogTitle>
          </DialogHeader>
          <form onSubmit={handleAdminPasswordSubmit} className="space-y-4">
            <div>
              <Label htmlFor="adminPassword" className="text-white font-bold">رمز عبور مدیریت</Label>
              <Input
                id="adminPassword"
                type="password"
                value={adminPassword}
                onChange={(e) => setAdminPassword(e.target.value)}
                className="bg-gray-800 border-gray-600 text-white font-bold"
                placeholder="رمز عبور مدیریت را وارد کنید"
                required
              />
            </div>
            <Button type="submit" className="w-full bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-600 hover:to-blue-700 text-black font-black">
              ورود
            </Button>
          </form>
        </DialogContent>
      </Dialog>

      {isAdminVerified && (
        <div className="p-6">
          {/* Header */}
          <div className="mb-8">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4">
                <div className="flex items-center space-x-2">
                  <Settings className="h-8 w-8 text-cyan-400" />
                  <h1 className="text-4xl font-black text-white">پنل مدیریت</h1>
                  <Star className="h-6 w-6 text-yellow-400" />
                </div>
              </div>
              <div className="flex items-center space-x-4">
                <Badge variant="secondary" className="bg-cyan-500 text-black font-bold">
                  مدیر: {user?.firstName || user?.email}
                </Badge>
                <Button onClick={() => window.location.href = "/"} variant="outline" className="border-gray-600 text-white hover:bg-gray-800 font-bold">
                  بازگشت به سایت
                </Button>
              </div>
            </div>
          </div>

          {/* Stats Cards */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
            <Card className="bg-gradient-to-br from-cyan-900/50 to-cyan-800/50 border-cyan-700">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-bold text-white">کل فروش</CardTitle>
                <DollarSign className="h-4 w-4 text-cyan-400" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-black text-white">$12,345</div>
                <p className="text-xs text-cyan-200 font-bold">+20.1% از ماه گذشته</p>
              </CardContent>
            </Card>
            <Card className="bg-gradient-to-br from-purple-900/50 to-purple-800/50 border-purple-700">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-bold text-white">سفارشات</CardTitle>
                <Package className="h-4 w-4 text-purple-400" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-black text-white">+573</div>
                <p className="text-xs text-purple-200 font-bold">+180.1% از ماه گذشته</p>
              </CardContent>
            </Card>
            <Card className="bg-gradient-to-br from-orange-900/50 to-orange-800/50 border-orange-700">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-bold text-white">کاربران</CardTitle>
                <Users className="h-4 w-4 text-orange-400" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-black text-white">+2,350</div>
                <p className="text-xs text-orange-200 font-bold">+19% از ماه گذشته</p>
              </CardContent>
            </Card>
            <Card className="bg-gradient-to-br from-green-900/50 to-green-800/50 border-green-700">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-bold text-white">رشد</CardTitle>
                <TrendingUp className="h-4 w-4 text-green-400" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-black text-white">+12.5%</div>
                <p className="text-xs text-green-200 font-bold">+2.5% از ماه گذشته</p>
              </CardContent>
            </Card>
          </div>

          {/* Admin Tabs */}
          <Tabs defaultValue="products" className="w-full">
            <TabsList className="grid w-full grid-cols-4 bg-gray-800 mb-6">
              <TabsTrigger value="products" className="text-white font-bold data-[state=active]:bg-cyan-600">
                <Package className="h-4 w-4 mr-2" />
                محصولات
              </TabsTrigger>
              <TabsTrigger value="orders" className="text-white font-bold data-[state=active]:bg-cyan-600">
                <DollarSign className="h-4 w-4 mr-2" />
                سفارشات
              </TabsTrigger>
              <TabsTrigger value="users" className="text-white font-bold data-[state=active]:bg-cyan-600">
                <Users className="h-4 w-4 mr-2" />
                کاربران
              </TabsTrigger>
              <TabsTrigger value="settings" className="text-white font-bold data-[state=active]:bg-cyan-600">
                <Settings className="h-4 w-4 mr-2" />
                تنظیمات
              </TabsTrigger>
            </TabsList>

            {/* Products Tab */}
            <TabsContent value="products" className="space-y-6">
              <div className="flex justify-between items-center">
                <h2 className="text-2xl font-black text-white">مدیریت محصولات</h2>
                <Dialog>
                  <DialogTrigger asChild>
                    <Button className="bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-600 hover:to-blue-700 text-black font-black">
                      <Plus className="h-4 w-4 mr-2" />
                      افزودن محصول جدید
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="bg-gray-900 border-gray-700 max-w-2xl">
                    <DialogHeader>
                      <DialogTitle className="text-white font-black">افزودن محصول جدید</DialogTitle>
                    </DialogHeader>
                    <div className="grid gap-4 py-4">
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <Label htmlFor="name" className="text-white font-bold">نام بازی</Label>
                          <Input id="name" className="bg-gray-800 border-gray-600 text-white font-bold" />
                        </div>
                        <div>
                          <Label htmlFor="price" className="text-white font-bold">قیمت</Label>
                          <Input id="price" type="number" className="bg-gray-800 border-gray-600 text-white font-bold" />
                        </div>
                      </div>
                      <div>
                        <Label htmlFor="description" className="text-white font-bold">توضیحات</Label>
                        <Textarea id="description" className="bg-gray-800 border-gray-600 text-white font-bold" />
                      </div>
                      <div>
                        <Label htmlFor="imageUrl" className="text-white font-bold">تصویر</Label>
                        <Input id="imageUrl" className="bg-gray-800 border-gray-600 text-white font-bold" />
                      </div>
                      <Button className="bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-600 hover:to-blue-700 text-black font-black">
                        افزودن محصول
                      </Button>
                    </div>
                  </DialogContent>
                </Dialog>
              </div>

              <div className="grid gap-4">
                {/* Sample Products */}
                {[
                  { id: 1, name: "Cyberpunk 2077", price: 59.99, category: "RPG", status: "فعال" },
                  { id: 2, name: "Call of Duty: MW3", price: 69.99, category: "Action", status: "فعال" },
                  { id: 3, name: "FIFA 24", price: 59.99, category: "Sports", status: "غیرفعال" },
                ].map((product) => (
                  <Card key={product.id} className="bg-gray-800 border-gray-700">
                    <CardContent className="flex items-center justify-between p-4">
                      <div className="flex items-center space-x-4">
                        <GamepadIcon className="h-10 w-10 text-cyan-400" />
                        <div>
                          <h3 className="font-black text-white">{product.name}</h3>
                          <p className="text-sm text-gray-400 font-bold">{product.category} • ${product.price}</p>
                        </div>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Badge 
                          variant={product.status === "فعال" ? "default" : "secondary"}
                          className={product.status === "فعال" ? "bg-green-500 text-black" : "bg-gray-500 text-white"}
                        >
                          {product.status}
                        </Badge>
                        <Button variant="ghost" size="sm" className="text-cyan-400 hover:text-cyan-300">
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button variant="ghost" size="sm" className="text-red-400 hover:text-red-300">
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>

            {/* Orders Tab */}
            <TabsContent value="orders" className="space-y-6">
              <h2 className="text-2xl font-black text-white">مدیریت سفارشات</h2>
              <div className="grid gap-4">
                {[
                  { id: 1, user: "کاربر 1", product: "Cyberpunk 2077", amount: 59.99, status: "تکمیل شده", date: "1403/08/15" },
                  { id: 2, user: "کاربر 2", product: "Call of Duty: MW3", amount: 69.99, status: "در انتظار", date: "1403/08/14" },
                  { id: 3, user: "کاربر 3", product: "FIFA 24", amount: 59.99, status: "لغو شده", date: "1403/08/13" },
                ].map((order) => (
                  <Card key={order.id} className="bg-gray-800 border-gray-700">
                    <CardContent className="flex items-center justify-between p-4">
                      <div>
                        <h3 className="font-black text-white">{order.product}</h3>
                        <p className="text-sm text-gray-400 font-bold">{order.user} • ${order.amount}</p>
                        <p className="text-xs text-gray-500 font-bold">{order.date}</p>
                      </div>
                      <Badge 
                        variant={order.status === "تکمیل شده" ? "default" : order.status === "در انتظار" ? "secondary" : "destructive"}
                        className={
                          order.status === "تکمیل شده" ? "bg-green-500 text-black" : 
                          order.status === "در انتظار" ? "bg-yellow-500 text-black" : 
                          "bg-red-500 text-white"
                        }
                      >
                        {order.status}
                      </Badge>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>

            {/* Users Tab */}
            <TabsContent value="users" className="space-y-6">
              <h2 className="text-2xl font-black text-white">مدیریت کاربران</h2>
              <div className="grid gap-4">
                {[
                  { id: 1, name: "کاربر یک", email: "user1@example.com", role: "کاربر", status: "فعال", joinDate: "1403/07/10" },
                  { id: 2, name: "کاربر دو", email: "user2@example.com", role: "کاربر", status: "فعال", joinDate: "1403/07/15" },
                  { id: 3, name: "کاربر سه", email: "user3@example.com", role: "مدیر", status: "فعال", joinDate: "1403/06/20" },
                ].map((user) => (
                  <Card key={user.id} className="bg-gray-800 border-gray-700">
                    <CardContent className="flex items-center justify-between p-4">
                      <div className="flex items-center space-x-4">
                        <div className="w-10 h-10 bg-gradient-to-br from-cyan-500 to-blue-600 rounded-full flex items-center justify-center">
                          <span className="text-black font-black">{user.name[0]}</span>
                        </div>
                        <div>
                          <h3 className="font-black text-white flex items-center">
                            {user.name}
                            {user.role === "مدیر" && <Star className="h-4 w-4 text-yellow-400 mr-1" />}
                          </h3>
                          <p className="text-sm text-gray-400 font-bold">{user.email}</p>
                          <p className="text-xs text-gray-500 font-bold">عضو از: {user.joinDate}</p>
                        </div>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Badge 
                          variant={user.role === "مدیر" ? "default" : "secondary"}
                          className={user.role === "مدیر" ? "bg-yellow-500 text-black" : "bg-gray-500 text-white"}
                        >
                          {user.role}
                        </Badge>
                        <Badge 
                          variant={user.status === "فعال" ? "default" : "destructive"}
                          className={user.status === "فعال" ? "bg-green-500 text-black" : "bg-red-500 text-white"}
                        >
                          {user.status}
                        </Badge>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>

            {/* Settings Tab */}
            <TabsContent value="settings" className="space-y-6">
              <h2 className="text-2xl font-black text-white">تنظیمات سایت</h2>
              <div className="grid gap-6">
                <Card className="bg-gray-800 border-gray-700">
                  <CardHeader>
                    <CardTitle className="text-white font-black">تنظیمات عمومی</CardTitle>
                    <CardDescription className="text-gray-400 font-bold">
                      تنظیمات کلی سایت را مدیریت کنید
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <Label htmlFor="siteName" className="text-white font-bold">نام سایت</Label>
                      <Input id="siteName" defaultValue="Crow Site" className="bg-gray-700 border-gray-600 text-white font-bold" />
                    </div>
                    <div>
                      <Label htmlFor="siteDescription" className="text-white font-bold">توضیحات سایت</Label>
                      <Textarea id="siteDescription" defaultValue="فروشگاه دیجیتال گیمینگ" className="bg-gray-700 border-gray-600 text-white font-bold" />
                    </div>
                    <Button className="bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-600 hover:to-blue-700 text-black font-black">
                      ذخیره تغییرات
                    </Button>
                  </CardContent>
                </Card>

                <Card className="bg-gray-800 border-gray-700">
                  <CardHeader>
                    <CardTitle className="text-white font-black">تنظیمات امنیتی</CardTitle>
                    <CardDescription className="text-gray-400 font-bold">
                      رمز عبور مدیریت و تنظیمات امنیتی
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <Label htmlFor="currentAdminPassword" className="text-white font-bold">رمز عبور فعلی مدیریت</Label>
                      <Input id="currentAdminPassword" type="password" className="bg-gray-700 border-gray-600 text-white font-bold" />
                    </div>
                    <div>
                      <Label htmlFor="newAdminPassword" className="text-white font-bold">رمز عبور جدید مدیریت</Label>
                      <Input id="newAdminPassword" type="password" className="bg-gray-700 border-gray-600 text-white font-bold" />
                    </div>
                    <Button className="bg-gradient-to-r from-red-500 to-red-600 hover:from-red-600 hover:to-red-700 text-white font-black">
                      تغییر رمز عبور
                    </Button>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      )}
    </div>
  );
}