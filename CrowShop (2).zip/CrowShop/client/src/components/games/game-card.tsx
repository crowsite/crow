import { useState } from 'react';
import { Heart, ShoppingCart } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { useCart } from '@/hooks/use-cart';
import type { Product } from '@shared/schema';

interface GameCardProps {
  product: Product;
}

export function GameCard({ product }: GameCardProps) {
  const [isWishlisted, setIsWishlisted] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const { addToCart } = useCart();

  const handleAddToCart = async () => {
    setIsLoading(true);
    
    // Simulate loading
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    addToCart(product);
    setIsLoading(false);
  };

  const toggleWishlist = () => {
    setIsWishlisted(!isWishlisted);
  };

  const renderStars = (rating: string) => {
    const ratingNum = parseFloat(rating);
    const stars = [];
    for (let i = 1; i <= 5; i++) {
      stars.push(
        <span
          key={i}
          className={i <= ratingNum ? 'text-gaming-orange' : 'text-gray-600'}
        >
          ★
        </span>
      );
    }
    return stars;
  };

  return (
    <div className="gaming-card rounded-2xl overflow-hidden group">
      <div className="relative">
        <img 
          src={product.imageUrl}
          alt={product.title}
          className="w-full h-48 object-cover group-hover:scale-110 transition-transform duration-500" 
        />
        {product.isNew && (
          <div className="absolute top-4 left-4 bg-gaming-orange text-white px-3 py-1 rounded-full text-sm font-bold">
            NEW
          </div>
        )}
        {product.isOnSale && (
          <div className="absolute top-4 left-4 bg-gaming-green text-white px-3 py-1 rounded-full text-sm font-bold">
            SALE
          </div>
        )}
        <Button
          variant="ghost"
          size="icon"
          onClick={toggleWishlist}
          className={`absolute top-4 right-4 text-2xl hover:scale-125 transition-transform ${
            isWishlisted ? 'text-red-500' : 'text-gray-400'
          }`}
        >
          <Heart className={`h-6 w-6 ${isWishlisted ? 'fill-current' : ''}`} />
        </Button>
      </div>
      
      <div className="p-6">
        <h3 className="text-xl orbitron font-bold mb-2">{product.title}</h3>
        <p className="text-gray-400 text-sm mb-4">{product.description}</p>
        
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center space-x-1">
            {renderStars(product.rating || "0")}
            <span className="text-sm text-gray-400 ml-2">{product.rating || "0"}</span>
          </div>
          <div className="text-right">
            {product.originalPrice && (
              <span className="text-lg line-through text-gray-500 mr-2">
                ${product.originalPrice}
              </span>
            )}
            <span className={`text-2xl font-bold ${
              product.isOnSale ? 'text-gaming-green' : 'text-neon-cyan'
            }`}>
              ${product.price}
            </span>
          </div>
        </div>
        
        <div className="flex gap-2 mb-4">
          <Badge variant="secondary" className="bg-gaming-purple/20 text-gaming-purple">
            {product.category}
          </Badge>
          {product.tags?.slice(0, 2).map((tag, index) => (
            <Badge key={index} variant="outline" className="border-neon-cyan/20 text-neon-cyan">
              {tag}
            </Badge>
          ))}
        </div>
        
        <Button 
          onClick={handleAddToCart}
          disabled={isLoading}
          className="w-full bg-gradient-to-r from-neon-cyan to-gaming-purple text-white hover:scale-105 transition-transform"
        >
          {isLoading ? (
            <>
              <div className="animate-spin h-4 w-4 mr-2 border-2 border-white border-t-transparent rounded-full" />
              Adding...
            </>
          ) : (
            <>
              <ShoppingCart className="h-4 w-4 mr-2" />
              Add to Cart
            </>
          )}
        </Button>
      </div>
    </div>
  );
}
