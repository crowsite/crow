import { useState } from 'react';
import { Button } from '@/components/ui/button';

interface GameFiltersProps {
  onFilterChange: (filter: string) => void;
  activeFilter: string;
}

export function GameFilters({ onFilterChange, activeFilter }: GameFiltersProps) {
  const filters = [
    { id: 'all', label: 'All Games' },
    { id: 'Action', label: 'Action' },
    { id: 'RPG', label: 'RPG' },
    { id: 'Strategy', label: 'Strategy' },
    { id: 'Indie', label: 'Indie' },
  ];

  return (
    <div className="flex flex-wrap justify-center gap-4 mb-12">
      {filters.map((filter) => (
        <Button
          key={filter.id}
          onClick={() => onFilterChange(filter.id)}
          variant={activeFilter === filter.id ? 'default' : 'secondary'}
          className={
            activeFilter === filter.id
              ? 'bg-neon-cyan text-dark-bg hover:bg-cyan-400'
              : 'bg-dark-card text-gray-300 hover:bg-gaming-purple hover:text-white'
          }
        >
          {filter.label}
        </Button>
      ))}
    </div>
  );
}
