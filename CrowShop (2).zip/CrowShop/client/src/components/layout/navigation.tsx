import { useState } from 'react';
import { Link, useLocation } from 'wouter';
import { ShoppingCart, User, Menu, X, LogOut } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useCart } from '@/hooks/use-cart';
import { useAuth } from '@/hooks/useAuth';
import { CartSidebar } from '@/components/cart/cart-sidebar';

export function Navigation() {
  const [, setLocation] = useLocation();
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const { cart } = useCart();
  const { user, isAuthenticated } = useAuth();

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
    setIsMobileMenuOpen(false);
  };

  return (
    <>
      <nav className="fixed top-0 left-0 right-0 z-50 glass-effect border-b border-neon-cyan/20 bg-black/80 backdrop-blur-md">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-4">
              <Link href="/" className="text-2xl font-black text-neon-cyan neon-text">
                <svg className="inline-block w-8 h-8 mr-2" viewBox="0 0 24 24" fill="currentColor">
                  <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/>
                </svg>
                Crow Site
              </Link>
            </div>
            
            <div className="hidden md:flex items-center space-x-8 font-bold">
              <button 
                onClick={() => scrollToSection('home')} 
                className="hover:text-neon-cyan transition-colors"
              >
                خانه
              </button>
              <button 
                onClick={() => scrollToSection('games')} 
                className="hover:text-neon-cyan transition-colors"
              >
                بازی‌ها
              </button>
              <button 
                onClick={() => scrollToSection('storage')} 
                className="hover:text-neon-cyan transition-colors"
              >
                مدیریت حافظه
              </button>
              {user?.isAdmin && (
                <Link href="/admin" className="hover:text-neon-cyan transition-colors">
                  مدیریت
                </Link>
              )}
            </div>
            
            <div className="flex items-center space-x-4">
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setIsCartOpen(true)}
                className="relative hover:text-neon-cyan"
              >
                <ShoppingCart className="h-5 w-5" />
                {cart.itemCount > 0 && (
                  <span className="absolute -top-1 -right-1 bg-gaming-orange text-xs rounded-full h-5 w-5 flex items-center justify-center font-bold">
                    {cart.itemCount}
                  </span>
                )}
              </Button>
              
              {isAuthenticated ? (
                <div className="flex items-center space-x-4">
                  <Link href="/profile">
                    <Button variant="ghost" size="icon" className="hover:text-neon-cyan">
                      <User className="h-5 w-5" />
                    </Button>
                  </Link>
                  <Button 
                    onClick={() => window.location.href = '/api/logout'}
                    variant="ghost" 
                    size="icon" 
                    className="hover:text-red-400"
                  >
                    <LogOut className="h-5 w-5" />
                  </Button>
                </div>
              ) : (
                <Button 
                  onClick={() => window.location.href = '/api/login'}
                  className="bg-neon-cyan text-black hover:bg-cyan-400 hidden md:flex font-bold"
                >
                  ورود / ثبت نام
                </Button>
              )}
              
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
                className="md:hidden"
              >
                {isMobileMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
              </Button>
            </div>
          </div>
          
          {/* Mobile menu */}
          {isMobileMenuOpen && (
            <div className="md:hidden border-t border-gray-600 py-4">
              <div className="flex flex-col space-y-3 font-bold">
                <button 
                  onClick={() => scrollToSection('home')} 
                  className="text-left hover:text-neon-cyan transition-colors"
                >
                  خانه
                </button>
                <button 
                  onClick={() => scrollToSection('games')} 
                  className="text-left hover:text-neon-cyan transition-colors"
                >
                  بازی‌ها
                </button>
                <button 
                  onClick={() => scrollToSection('storage')} 
                  className="text-left hover:text-neon-cyan transition-colors"
                >
                  مدیریت حافظه
                </button>
                {user?.isAdmin && (
                  <Link href="/admin" className="text-left hover:text-neon-cyan transition-colors">
                    مدیریت
                  </Link>
                )}
                {isAuthenticated ? (
                  <div className="flex flex-col space-y-3">
                    <Link href="/profile" className="text-left hover:text-neon-cyan transition-colors">
                      پروفایل
                    </Link>
                    <button 
                      onClick={() => window.location.href = '/api/logout'}
                      className="text-left hover:text-red-400 transition-colors"
                    >
                      خروج
                    </button>
                  </div>
                ) : (
                  <Button 
                    onClick={() => window.location.href = '/api/login'}
                    className="bg-neon-cyan text-black hover:bg-cyan-400 justify-start font-bold"
                  >
                    ورود / ثبت نام
                  </Button>
                )}
              </div>
            </div>
          )}
        </div>
      </nav>
      
      <CartSidebar isOpen={isCartOpen} onClose={() => setIsCartOpen(false)} />
    </>
  );
}