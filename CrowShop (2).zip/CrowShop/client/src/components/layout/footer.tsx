import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';

export function Footer() {
  return (
    <footer className="bg-gradient-to-t from-dark-bg to-dark-card py-16 border-t border-neon-cyan/20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-12">
          <div>
            <div className="text-2xl orbitron font-black text-neon-cyan neon-text mb-4">
              <svg className="inline-block w-6 h-6 mr-2" viewBox="0 0 24 24" fill="currentColor">
                <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/>
              </svg>
              CROW SITE
            </div>
            <p className="text-gray-400 mb-4">The ultimate destination for digital gaming experiences.</p>
            <div className="flex space-x-4">
              <Button variant="ghost" size="icon" className="text-gray-400 hover:text-neon-cyan">
                <svg className="h-5 w-5" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M23.953 4.57a10 10 0 01-2.825.775 4.958 4.958 0 002.163-2.723c-.951.555-2.005.959-3.127 1.184a4.92 4.92 0 00-8.384 4.482C7.69 8.095 4.067 6.13 1.64 3.162a4.822 4.822 0 00-.666 2.475c0 1.71.87 3.213 2.188 4.096a4.904 4.904 0 01-2.228-.616v.06a4.923 4.923 0 003.946 4.827 4.996 4.996 0 01-2.212.085 4.936 4.936 0 004.604 3.417 9.867 9.867 0 01-6.102 2.105c-.39 0-.779-.023-1.17-.067a13.995 13.995 0 007.557 2.209c9.053 0 13.998-7.496 13.998-13.985 0-.21 0-.42-.015-.63A9.935 9.935 0 0024 4.59z"/>
                </svg>
              </Button>
              <Button variant="ghost" size="icon" className="text-gray-400 hover:text-neon-cyan">
                <svg className="h-5 w-5" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M20.317 4.37a19.791 19.791 0 0 0-4.885-1.515a.074.074 0 0 0-.079.037c-.21.375-.444.864-.608 1.25a18.27 18.27 0 0 0-5.487 0a12.64 12.64 0 0 0-.617-1.25a.077.077 0 0 0-.079-.037A19.736 19.736 0 0 0 3.677 4.37a.07.07 0 0 0-.032.027C.533 9.046-.32 13.58.099 18.057a.082.082 0 0 0 .031.057a19.9 19.9 0 0 0 5.993 3.03a.078.078 0 0 0 .084-.028a14.09 14.09 0 0 0 1.226-1.994a.076.076 0 0 0-.041-.106a13.107 13.107 0 0 1-1.872-.892a.077.077 0 0 1-.008-.128a10.2 10.2 0 0 0 .372-.292a.074.074 0 0 1 .077-.01c3.928 1.793 8.18 1.793 12.062 0a.074.074 0 0 1 .078.01c.12.098.246.198.373.292a.077.077 0 0 1-.006.127a12.299 12.299 0 0 1-1.873.892a.077.077 0 0 0-.041.107c.36.698.772 1.362 1.225 1.993a.076.076 0 0 0 .084.028a19.839 19.839 0 0 0 6.002-3.03a.077.077 0 0 0 .032-.054c.5-5.177-.838-9.674-3.549-13.66a.061.061 0 0 0-.031-.03zM8.02 15.33c-1.183 0-2.157-1.085-2.157-2.419c0-1.333.956-2.419 2.157-2.419c1.21 0 2.176 1.096 2.157 2.42c0 1.333-.956 2.418-2.157 2.418zm7.975 0c-1.183 0-2.157-1.085-2.157-2.419c0-1.333.955-2.419 2.157-2.419c1.21 0 2.176 1.096 2.157 2.42c0 1.333-.946 2.418-2.157 2.418Z"/>
                </svg>
              </Button>
              <Button variant="ghost" size="icon" className="text-gray-400 hover:text-neon-cyan">
                <svg className="h-5 w-5" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M11.64 5.93a1.38 1.38 0 0 1 .72 0c.2.05.37.17.47.35l.84 1.69c.1.2.29.34.51.37l1.87.27c.41.06.57.56.27.85l-1.35 1.32c-.16.16-.23.38-.2.6l.32 1.86c.07.41-.36.72-.73.53l-1.67-.88c-.2-.1-.43-.1-.62 0l-1.67.88c-.37.19-.8-.12-.73-.53l.32-1.86c.03-.22-.04-.44-.2-.6L7.45 9.41c-.3-.29-.14-.79.27-.85l1.87-.27c.22-.03.41-.17.51-.37l.84-1.69c.17-.37.71-.37.7 0z"/>
                </svg>
              </Button>
              <Button variant="ghost" size="icon" className="text-gray-400 hover:text-neon-cyan">
                <svg className="h-5 w-5" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z"/>
                </svg>
              </Button>
            </div>
          </div>
          
          <div>
            <h4 className="text-lg orbitron font-bold text-white mb-4">Store</h4>
            <ul className="space-y-2 text-gray-400">
              <li><button className="hover:text-neon-cyan transition-colors text-left">Browse Games</button></li>
              <li><button className="hover:text-neon-cyan transition-colors text-left">New Releases</button></li>
              <li><button className="hover:text-neon-cyan transition-colors text-left">Top Sellers</button></li>
              <li><button className="hover:text-neon-cyan transition-colors text-left">Free Games</button></li>
            </ul>
          </div>
          
          <div>
            <h4 className="text-lg orbitron font-bold text-white mb-4">Support</h4>
            <ul className="space-y-2 text-gray-400">
              <li><button className="hover:text-neon-cyan transition-colors text-left">Help Center</button></li>
              <li><button className="hover:text-neon-cyan transition-colors text-left">Contact Us</button></li>
              <li><button className="hover:text-neon-cyan transition-colors text-left">Bug Reports</button></li>
              <li><button className="hover:text-neon-cyan transition-colors text-left">Community</button></li>
            </ul>
          </div>
          
          <div>
            <h4 className="text-lg orbitron font-bold text-white mb-4">Newsletter</h4>
            <p className="text-gray-400 mb-4">Get the latest gaming news and exclusive offers.</p>
            <div className="flex">
              <Input 
                type="email" 
                placeholder="Your email" 
                className="flex-1 bg-dark-bg border-gray-600 focus:border-neon-cyan rounded-r-none"
              />
              <Button className="bg-neon-cyan text-dark-bg hover:bg-cyan-400 rounded-l-none">
                <svg className="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" />
                </svg>
              </Button>
            </div>
          </div>
        </div>
        
        <div className="border-t border-gray-700 pt-8 text-center text-gray-400">
          <p>&copy; 2024 Crow Site. All rights reserved. | Privacy Policy | Terms of Service</p>
        </div>
      </div>
    </footer>
  );
}
