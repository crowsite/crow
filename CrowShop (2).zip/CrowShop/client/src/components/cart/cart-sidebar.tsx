import { X, CreditCard, Trash2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useCart } from '@/hooks/use-cart';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';

interface CartSidebarProps {
  isOpen: boolean;
  onClose: () => void;
}

export function CartSidebar({ isOpen, onClose }: CartSidebarProps) {
  const { cart, removeFromCart, clearCart } = useCart();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const checkoutMutation = useMutation({
    mutationFn: async () => {
      const orderData = {
        userId: 'demo-user', // In a real app, this would come from auth
        total: cart.total.toString(),
        items: cart.items.map(item => ({
          productId: item.id,
          quantity: item.quantity,
          price: item.price,
        })),
      };
      
      return apiRequest('POST', '/api/orders', orderData);
    },
    onSuccess: () => {
      clearCart();
      onClose();
      toast({
        title: "Order Placed Successfully!",
        description: "Your games will be available in your library shortly.",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/orders'] });
    },
    onError: () => {
      toast({
        title: "Checkout Failed",
        description: "There was an error processing your order. Please try again.",
        variant: "destructive",
      });
    },
  });

  return (
    <div className={`fixed top-0 right-0 h-full w-96 glass-effect transform transition-transform duration-300 z-50 border-l border-neon-cyan/20 ${
      isOpen ? 'translate-x-0' : 'translate-x-full'
    }`}>
      <div className="p-6 h-full flex flex-col">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-2xl orbitron font-bold text-neon-cyan">Shopping Cart</h3>
          <Button variant="ghost" size="icon" onClick={onClose}>
            <X className="h-5 w-5" />
          </Button>
        </div>
        
        <div className="flex-1 overflow-y-auto space-y-4">
          {cart.items.length === 0 ? (
            <div className="text-center py-8">
              <p className="text-gray-400">Your cart is empty</p>
            </div>
          ) : (
            cart.items.map((item) => (
              <div key={item.id} className="gaming-card p-4 rounded-lg">
                <div className="flex items-center space-x-4">
                  <img 
                    src={item.imageUrl}
                    alt={item.title}
                    className="w-16 h-12 object-cover rounded" 
                  />
                  <div className="flex-1">
                    <h4 className="font-semibold">{item.title}</h4>
                    <p className="text-neon-cyan font-bold">${item.price}</p>
                  </div>
                  <Button 
                    variant="ghost" 
                    size="icon"
                    onClick={() => removeFromCart(item.id)}
                    className="text-red-500 hover:text-red-400"
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            ))
          )}
        </div>
        
        {cart.items.length > 0 && (
          <div className="border-t border-gray-600 pt-6 mt-6">
            <div className="flex justify-between items-center mb-4">
              <span className="text-lg font-semibold">Total:</span>
              <span className="text-2xl font-bold text-neon-cyan">${cart.total.toFixed(2)}</span>
            </div>
            
            <Button 
              onClick={() => checkoutMutation.mutate()}
              disabled={checkoutMutation.isPending}
              className="w-full bg-gradient-to-r from-neon-cyan to-gaming-purple text-white py-4 text-lg hover:scale-105 transition-transform mb-3"
            >
              {checkoutMutation.isPending ? (
                <>
                  <div className="animate-spin h-4 w-4 mr-2 border-2 border-white border-t-transparent rounded-full" />
                  Processing...
                </>
              ) : (
                <>
                  <CreditCard className="h-5 w-5 mr-2" />
                  Checkout
                </>
              )}
            </Button>
            
            <Button 
              variant="outline"
              onClick={clearCart}
              className="w-full border-gray-600 text-gray-300 hover:border-neon-cyan hover:text-neon-cyan"
            >
              Clear Cart
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}
