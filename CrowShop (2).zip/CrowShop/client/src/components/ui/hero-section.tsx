import { Button } from '@/components/ui/button';
import { Gamepad2, Database, Zap, Shield, Star } from 'lucide-react';

export function HeroSection() {
  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section id="home" className="relative min-h-screen cyber-grid flex items-center justify-center pt-16">
      <div className="absolute inset-0 bg-gradient-to-br from-dark-bg via-dark-bg/90 to-gaming-purple/20"></div>
      
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <div className="mb-8 relative">
          <img 
            src="https://images.unsplash.com/photo-1542751371-adc38448a05e?ixlib=rb-4.0.3&auto=format&fit=crop&w=1200&h=600" 
            alt="Gaming setup with neon lighting" 
            className="rounded-2xl shadow-2xl mx-auto w-full max-w-4xl opacity-80 animate-float" 
          />
          <div className="absolute inset-0 bg-gradient-to-t from-dark-bg/80 to-transparent rounded-2xl"></div>
        </div>
        
        <h1 className="text-6xl md:text-8xl orbitron font-black mb-6 animate-glow">
          <span className="text-neon-cyan neon-text">CROW</span>
          <span className="text-gaming-orange"> SITE</span>
        </h1>
        
        <p className="text-xl md:text-2xl text-gray-300 mb-8 max-w-3xl mx-auto">
          The Ultimate Gaming Digital Store - Discover, Purchase, and Play the Latest Games
        </p>
        
        <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
          <Button 
            size="lg"
            onClick={() => scrollToSection('games')}
            className="bg-gradient-to-r from-neon-cyan to-gaming-purple px-8 py-4 text-lg hover:scale-105 transition-transform neon-border animate-glow"
          >
            <Gamepad2 className="h-5 w-5 mr-2" />
            Explore Games
          </Button>
          <Button 
            variant="outline"
            size="lg"
            onClick={() => scrollToSection('storage')}
            className="border-2 border-gaming-orange text-gaming-orange px-8 py-4 text-lg hover:bg-gaming-orange hover:text-white transition-colors"
          >
            <Database className="h-5 w-5 mr-2" />
            View Storage
          </Button>
        </div>
        
        <div className="mt-16 grid grid-cols-1 md:grid-cols-3 gap-8 max-w-4xl mx-auto">
          <div className="gaming-card p-6 rounded-xl text-center">
            <Zap className="h-12 w-12 text-neon-cyan mb-4 mx-auto" />
            <h3 className="text-xl orbitron font-bold mb-2">Lightning Fast</h3>
            <p className="text-gray-400">Instant downloads and seamless gaming experience</p>
          </div>
          <div className="gaming-card p-6 rounded-xl text-center">
            <Shield className="h-12 w-12 text-gaming-green mb-4 mx-auto" />
            <h3 className="text-xl orbitron font-bold mb-2">Secure</h3>
            <p className="text-gray-400">Protected transactions and verified game publishers</p>
          </div>
          <div className="gaming-card p-6 rounded-xl text-center">
            <Star className="h-12 w-12 text-gaming-orange mb-4 mx-auto" />
            <h3 className="text-xl orbitron font-bold mb-2">Premium Quality</h3>
            <p className="text-gray-400">Curated collection of the best gaming experiences</p>
          </div>
        </div>
      </div>
    </section>
  );
}
