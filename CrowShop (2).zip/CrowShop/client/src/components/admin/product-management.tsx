import { useState } from 'react';
import { Plus, Search, Edit, BarChart3, Trash2, ChevronLeft, ChevronRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { useQuery } from '@tanstack/react-query';
import type { Product } from '@shared/schema';

export function ProductManagement() {
  const [searchQuery, setSearchQuery] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('all');
  const [statusFilter, setStatusFilter] = useState('all');

  const { data: products = [], isLoading } = useQuery<Product[]>({
    queryKey: ['/api/products'],
  });

  const filteredProducts = products.filter(product => {
    const matchesSearch = product.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         product.description.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = categoryFilter === 'all' || product.category === categoryFilter;
    const matchesStatus = statusFilter === 'all' || product.status === statusFilter;
    
    return matchesSearch && matchesCategory && matchesStatus;
  });

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h3 className="text-2xl orbitron font-bold text-neon-cyan">Product Management</h3>
        <Button className="bg-gaming-green text-white hover:bg-green-600">
          <Plus className="h-4 w-4 mr-2" />
          Add New Product
        </Button>
      </div>
      
      {/* Search and Filter */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
          <Input
            placeholder="Search products..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10 bg-dark-bg border-gray-600 focus:border-neon-cyan"
          />
        </div>
        <Select value={categoryFilter} onValueChange={setCategoryFilter}>
          <SelectTrigger className="bg-dark-bg border-gray-600 focus:border-neon-cyan">
            <SelectValue placeholder="All Categories" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Categories</SelectItem>
            <SelectItem value="Action">Action</SelectItem>
            <SelectItem value="RPG">RPG</SelectItem>
            <SelectItem value="Strategy">Strategy</SelectItem>
            <SelectItem value="Indie">Indie</SelectItem>
          </SelectContent>
        </Select>
        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="bg-dark-bg border-gray-600 focus:border-neon-cyan">
            <SelectValue placeholder="All Status" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Status</SelectItem>
            <SelectItem value="active">Active</SelectItem>
            <SelectItem value="draft">Draft</SelectItem>
            <SelectItem value="discontinued">Discontinued</SelectItem>
          </SelectContent>
        </Select>
      </div>
      
      {/* Products Table */}
      <div className="overflow-x-auto">
        <table className="w-full text-left">
          <thead>
            <tr className="border-b border-gray-600">
              <th className="py-4 px-4 orbitron text-neon-cyan">Product</th>
              <th className="py-4 px-4 orbitron text-neon-cyan">Category</th>
              <th className="py-4 px-4 orbitron text-neon-cyan">Price</th>
              <th className="py-4 px-4 orbitron text-neon-cyan">Sales</th>
              <th className="py-4 px-4 orbitron text-neon-cyan">Status</th>
              <th className="py-4 px-4 orbitron text-neon-cyan">Actions</th>
            </tr>
          </thead>
          <tbody>
            {isLoading ? (
              [...Array(5)].map((_, i) => (
                <tr key={i} className="border-b border-gray-700">
                  <td className="py-4 px-4">
                    <div className="flex items-center space-x-3">
                      <div className="w-12 h-8 bg-gray-700 rounded animate-pulse"></div>
                      <div>
                        <div className="h-4 w-32 bg-gray-700 rounded animate-pulse mb-1"></div>
                        <div className="h-3 w-20 bg-gray-700 rounded animate-pulse"></div>
                      </div>
                    </div>
                  </td>
                  <td className="py-4 px-4"><div className="h-4 w-16 bg-gray-700 rounded animate-pulse"></div></td>
                  <td className="py-4 px-4"><div className="h-4 w-12 bg-gray-700 rounded animate-pulse"></div></td>
                  <td className="py-4 px-4"><div className="h-4 w-8 bg-gray-700 rounded animate-pulse"></div></td>
                  <td className="py-4 px-4"><div className="h-6 w-16 bg-gray-700 rounded animate-pulse"></div></td>
                  <td className="py-4 px-4"><div className="h-4 w-20 bg-gray-700 rounded animate-pulse"></div></td>
                </tr>
              ))
            ) : (
              filteredProducts.map((product) => (
                <tr key={product.id} className="border-b border-gray-700 hover:bg-dark-bg/50 transition-colors">
                  <td className="py-4 px-4">
                    <div className="flex items-center space-x-3">
                      <img 
                        src={product.imageUrl}
                        alt={product.title}
                        className="w-12 h-8 object-cover rounded" 
                      />
                      <div>
                        <p className="font-semibold">{product.title}</p>
                        <p className="text-sm text-gray-400">ID: #{product.id.slice(0, 8)}</p>
                      </div>
                    </div>
                  </td>
                  <td className="py-4 px-4">{product.category}</td>
                  <td className="py-4 px-4 text-neon-cyan font-semibold">${product.price}</td>
                  <td className="py-4 px-4">{product.sales}</td>
                  <td className="py-4 px-4">
                    <Badge 
                      variant="secondary" 
                      className={
                        product.status === 'active' 
                          ? 'bg-gaming-green/20 text-gaming-green' 
                          : 'bg-gray-500/20 text-gray-500'
                      }
                    >
                      {product.status}
                    </Badge>
                  </td>
                  <td className="py-4 px-4">
                    <div className="flex space-x-2">
                      <Button variant="ghost" size="icon" className="text-neon-cyan hover:text-cyan-400" title="Edit">
                        <Edit className="h-4 w-4" />
                      </Button>
                      <Button variant="ghost" size="icon" className="text-gaming-orange hover:text-orange-400" title="Analytics">
                        <BarChart3 className="h-4 w-4" />
                      </Button>
                      <Button variant="ghost" size="icon" className="text-red-500 hover:text-red-400" title="Delete">
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
      
      {/* Pagination */}
      <div className="flex justify-between items-center mt-8">
        <p className="text-gray-400">Showing 1-{filteredProducts.length} of {filteredProducts.length} products</p>
        <div className="flex space-x-2">
          <Button variant="outline" size="icon" className="border-gray-600 hover:border-neon-cyan">
            <ChevronLeft className="h-4 w-4" />
          </Button>
          <Button className="bg-neon-cyan text-dark-bg">1</Button>
          <Button variant="outline" className="border-gray-600 hover:border-neon-cyan">2</Button>
          <Button variant="outline" className="border-gray-600 hover:border-neon-cyan">3</Button>
          <Button variant="outline" size="icon" className="border-gray-600 hover:border-neon-cyan">
            <ChevronRight className="h-4 w-4" />
          </Button>
        </div>
      </div>
    </div>
  );
}
