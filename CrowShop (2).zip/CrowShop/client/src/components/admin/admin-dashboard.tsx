import { Users, ShoppingBag, Gamepad2, Download } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { useQuery } from '@tanstack/react-query';

export function AdminDashboard() {
  const { data: analytics, isLoading } = useQuery({
    queryKey: ['/api/analytics/dashboard'],
  });

  if (isLoading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
        {[...Array(4)].map((_, i) => (
          <Card key={i} className="gaming-card animate-pulse">
            <CardContent className="p-6">
              <div className="h-16 bg-gray-700 rounded mb-4"></div>
              <div className="h-4 bg-gray-700 rounded mb-2"></div>
              <div className="h-8 bg-gray-700 rounded"></div>
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  const stats = [
    {
      title: "Total Users",
      value: "15,847",
      change: "+12%",
      icon: Users,
      color: "text-neon-cyan",
    },
    {
      title: "Sales Today", 
      value: `$${(analytics as any)?.totalSales?.toFixed(2) || '0.00'}`,
      change: "+8%",
      icon: ShoppingBag,
      color: "text-gaming-green",
    },
    {
      title: "Games Listed",
      value: (analytics as any)?.totalProducts?.toString() || '0',
      change: "+23 new",
      icon: Gamepad2,
      color: "text-gaming-orange",
    },
    {
      title: "Downloads",
      value: (analytics as any)?.totalDownloads?.toString() || '0',
      change: "+15%",
      icon: Download,
      color: "text-gaming-purple",
    },
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
      {stats.map((stat, index) => (
        <Card key={index} className="gaming-card">
          <CardContent className="p-6 text-center">
            <stat.icon className={`h-12 w-12 ${stat.color} mb-4 mx-auto`} />
            <CardTitle className="text-lg orbitron font-bold mb-2">{stat.title}</CardTitle>
            <p className={`text-3xl font-black ${stat.color}`}>{stat.value}</p>
            <p className="text-sm text-green-400 mt-1">{stat.change} this month</p>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
