import { HardDrive, Download, Cloud, Play, RotateCcw, Trash2, CheckCircle, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';

export function StorageOverview() {
  const storageData = {
    total: "2.5TB",
    used: "847GB",
    cloud: "12.3GB",
    games: "673GB",
    screenshots: "124GB",
    videos: "50GB",
  };

  const installedGames = [
    {
      id: "1",
      title: "Cyber Nexus 2077",
      imageUrl: "https://images.unsplash.com/photo-1550745165-9bc0b252726f?ixlib=rb-4.0.3&auto=format&fit=crop&w=80&h=60",
      size: "45.2 GB",
      installDate: "Jan 15, 2024",
      status: "installed",
    },
    {
      id: "2", 
      title: "Mystic Realms",
      imageUrl: "https://images.unsplash.com/photo-1578662996442-48f60103fc96?ixlib=rb-4.0.3&auto=format&fit=crop&w=80&h=60",
      size: "32.7 GB",
      installDate: "Jan 10, 2024",
      status: "installed",
    },
    {
      id: "3",
      title: "Galactic Empire",
      imageUrl: "https://images.unsplash.com/photo-1446776653964-20c1d3a81b06?ixlib=rb-4.0.3&auto=format&fit=crop&w=80&h=60",
      size: "26.8 GB / 40.1 GB",
      installDate: "",
      status: "downloading",
      progress: 67,
    },
  ];

  return (
    <section id="storage" className="py-20 bg-gradient-to-b from-dark-card to-dark-bg">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-5xl orbitron font-black text-neon-cyan neon-text mb-4">
            STORAGE CENTER
          </h2>
          <p className="text-xl text-gray-300 max-w-2xl mx-auto">
            Manage your digital library and storage efficiently
          </p>
        </div>
        
        {/* Storage Overview */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
          <div className="gaming-card p-8 rounded-2xl text-center holographic">
            <HardDrive className="h-14 w-14 text-neon-cyan mb-4 mx-auto" />
            <h3 className="text-2xl orbitron font-bold mb-2">Total Storage</h3>
            <p className="text-4xl font-black text-neon-cyan">{storageData.total}</p>
            <p className="text-gray-400 mt-2">Available Space</p>
          </div>
          
          <div className="gaming-card p-8 rounded-2xl text-center">
            <Download className="h-14 w-14 text-gaming-green mb-4 mx-auto" />
            <h3 className="text-2xl orbitron font-bold mb-2">Downloaded</h3>
            <p className="text-4xl font-black text-gaming-green">{storageData.used}</p>
            <p className="text-gray-400 mt-2">Games Installed</p>
          </div>
          
          <div className="gaming-card p-8 rounded-2xl text-center">
            <Cloud className="h-14 w-14 text-gaming-purple mb-4 mx-auto" />
            <h3 className="text-2xl orbitron font-bold mb-2">Cloud Saves</h3>
            <p className="text-4xl font-black text-gaming-purple">{storageData.cloud}</p>
            <p className="text-gray-400 mt-2">Synced Data</p>
          </div>
        </div>
        
        {/* Storage Progress */}
        <div className="gaming-card p-8 rounded-2xl mb-8">
          <h3 className="text-2xl orbitron font-bold mb-6 text-neon-cyan">Storage Usage</h3>
          <div className="space-y-4">
            <div>
              <div className="flex justify-between mb-2">
                <span className="text-lg">Games</span>
                <span className="text-neon-cyan">{storageData.games} / {storageData.total}</span>
              </div>
              <Progress value={27} className="h-3" />
            </div>
            
            <div>
              <div className="flex justify-between mb-2">
                <span className="text-lg">Screenshots</span>
                <span className="text-gaming-orange">{storageData.screenshots} / {storageData.total}</span>
              </div>
              <Progress value={5} className="h-3" />
            </div>
            
            <div>
              <div className="flex justify-between mb-2">
                <span className="text-lg">Videos</span>
                <span className="text-gaming-green">{storageData.videos} / {storageData.total}</span>
              </div>
              <Progress value={2} className="h-3" />
            </div>
          </div>
        </div>
        
        {/* Installed Games List */}
        <div className="gaming-card p-8 rounded-2xl">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-2xl orbitron font-bold text-neon-cyan">Installed Games</h3>
            <Button className="bg-gaming-orange text-white hover:bg-orange-600">
              <RotateCcw className="h-4 w-4 mr-2" />
              Optimize Storage
            </Button>
          </div>
          
          <div className="space-y-4">
            {installedGames.map((game) => (
              <div 
                key={game.id}
                className={`flex items-center justify-between p-4 bg-dark-bg rounded-lg border transition-colors ${
                  game.status === 'downloading' 
                    ? 'border-yellow-500' 
                    : 'border-gray-700 hover:border-neon-cyan'
                }`}
              >
                <div className="flex items-center space-x-4">
                  <img 
                    src={game.imageUrl}
                    alt={game.title}
                    className="w-16 h-12 object-cover rounded" 
                  />
                  <div>
                    <h4 className="font-semibold">{game.title}</h4>
                    {game.status === 'downloading' ? (
                      <div className="space-y-1">
                        <p className="text-sm text-yellow-500">Downloading: {game.progress}% complete</p>
                        <Progress value={game.progress} className="w-32 h-2" />
                      </div>
                    ) : (
                      <p className="text-sm text-gray-400">Installed: {game.installDate}</p>
                    )}
                  </div>
                </div>
                
                <div className="flex items-center space-x-4">
                  <span className="text-neon-cyan font-semibold">{game.size}</span>
                  <div className="flex space-x-2">
                    {game.status === 'installed' ? (
                      <>
                        <Button variant="ghost" size="icon" className="text-gaming-green hover:text-green-400" title="Launch Game">
                          <Play className="h-4 w-4" />
                        </Button>
                        <Button variant="ghost" size="icon" className="text-gray-500" title="Up to date">
                          <CheckCircle className="h-4 w-4" />
                        </Button>
                        <Button variant="ghost" size="icon" className="text-red-500 hover:text-red-400" title="Uninstall">
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </>
                    ) : (
                      <Button variant="ghost" size="icon" className="text-red-500 hover:text-red-400" title="Cancel Download">
                        <X className="h-4 w-4" />
                      </Button>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
