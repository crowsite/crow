import { 
  type User, 
  type InsertUser,
  type UpsertUser,
  type Product, 
  type InsertProduct,
  type Order,
  type InsertOrder,
  type OrderItem,
  type InsertOrderItem,
  type UserLibrary,
  type InsertUserLibrary,
  type Wishlist,
  type InsertWishlist
} from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // User operations
  // (IMPORTANT) these user operations are mandatory for Replit Auth.
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: string, updates: Partial<User>): Promise<User | undefined>;
  
  // Products
  getProducts(): Promise<Product[]>;
  getProduct(id: string): Promise<Product | undefined>;
  getProductsByCategory(category: string): Promise<Product[]>;
  searchProducts(query: string): Promise<Product[]>;
  createProduct(product: InsertProduct): Promise<Product>;
  updateProduct(id: string, product: Partial<Product>): Promise<Product | undefined>;
  deleteProduct(id: string): Promise<boolean>;
  
  // Orders
  getOrders(): Promise<Order[]>;
  getOrder(id: string): Promise<Order | undefined>;
  getUserOrders(userId: string): Promise<Order[]>;
  createOrder(order: InsertOrder): Promise<Order>;
  updateOrderStatus(id: string, status: string): Promise<Order | undefined>;
  
  // Order Items
  getOrderItems(orderId: string): Promise<OrderItem[]>;
  createOrderItem(orderItem: InsertOrderItem): Promise<OrderItem>;
  
  // User Library
  getUserLibrary(userId: string): Promise<UserLibrary[]>;
  addToLibrary(userLibrary: InsertUserLibrary): Promise<UserLibrary>;
  updateLibraryItem(userId: string, productId: string, updates: Partial<UserLibrary>): Promise<UserLibrary | undefined>;
  
  // Wishlist
  getUserWishlist(userId: string): Promise<Wishlist[]>;
  addToWishlist(wishlist: InsertWishlist): Promise<Wishlist>;
  removeFromWishlist(userId: string, productId: string): Promise<boolean>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User> = new Map();
  private products: Map<string, Product> = new Map();
  private orders: Map<string, Order> = new Map();
  private orderItems: Map<string, OrderItem> = new Map();
  private userLibrary: Map<string, UserLibrary> = new Map();
  private wishlist: Map<string, Wishlist> = new Map();

  constructor() {
    this.seedData();
  }

  private seedData() {
    // Create admin user for development
    const adminUser: User = {
      id: "admin-user-id",
      email: "admin@crowsite.com",
      firstName: "مدیر",
      lastName: "سایت",
      profileImageUrl: "https://api.dicebear.com/7.x/avataaars/svg?seed=Admin&backgroundColor=b6e3f4,c0aede,d1d4f9,ffd5dc,ffdfbf",
      isAdmin: true,
      googleId: null,
      bio: null,
      birthDate: null,
      phoneNumber: null,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    this.users.set(adminUser.id, adminUser);

    // Create sample products
    const sampleProducts: Product[] = [
      {
        id: randomUUID(),
        title: "Cyber Nexus 2077",
        description: "Epic cyberpunk adventure in a dystopian future with stunning graphics and immersive gameplay.",
        price: "59.99",
        originalPrice: null,
        category: "Action",
        tags: ["Action", "RPG", "Cyberpunk", "Open World"],
        imageUrl: "https://images.unsplash.com/photo-1550745165-9bc0b252726f?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300",
        rating: "4.8",
        sales: 1247,
        status: "active",
        size: "45.2 GB",
        isNew: true,
        isOnSale: false,
        createdAt: new Date(),
      },
      {
        id: randomUUID(),
        title: "Mystic Realms",
        description: "Embark on an epic fantasy adventure with magic, dragons, and legendary quests.",
        price: "29.99",
        originalPrice: "49.99",
        category: "RPG",
        tags: ["RPG", "Fantasy", "Magic", "Adventure"],
        imageUrl: "https://images.unsplash.com/photo-1578662996442-48f60103fc96?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300",
        rating: "5.0",
        sales: 2156,
        status: "active",
        size: "32.7 GB",
        isNew: false,
        isOnSale: true,
        createdAt: new Date(),
      },
      {
        id: randomUUID(),
        title: "Galactic Empire",
        description: "Command fleets in strategic space warfare across the galaxy.",
        price: "39.99",
        originalPrice: null,
        category: "Strategy",
        tags: ["Strategy", "Sci-Fi", "Space", "Tactical"],
        imageUrl: "https://images.unsplash.com/photo-1446776653964-20c1d3a81b06?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300",
        rating: "4.2",
        sales: 876,
        status: "active",
        size: "28.4 GB",
        isNew: false,
        isOnSale: false,
        createdAt: new Date(),
      },
      {
        id: randomUUID(),
        title: "Pixel Quest",
        description: "Retro-style platformer with modern gameplay mechanics and charming pixel art.",
        price: "19.99",
        originalPrice: null,
        category: "Indie",
        tags: ["Indie", "Platformer", "Pixel Art", "Retro"],
        imageUrl: "https://images.unsplash.com/photo-1493711662062-fa541adb3fc8?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300",
        rating: "4.9",
        sales: 3421,
        status: "active",
        size: "2.1 GB",
        isNew: false,
        isOnSale: false,
        createdAt: new Date(),
      },
    ];

    sampleProducts.forEach(product => {
      this.products.set(product.id, product);
    });
  }

  // User operations
  // (IMPORTANT) these user operations are mandatory for Replit Auth.
  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const userId = userData.id || randomUUID();
    const existingUser = this.users.get(userId);
    if (existingUser) {
      const updatedUser: User = {
        ...existingUser,
        email: userData.email || existingUser.email,
        firstName: userData.firstName || existingUser.firstName,
        lastName: userData.lastName || existingUser.lastName,
        profileImageUrl: userData.profileImageUrl || existingUser.profileImageUrl,
        googleId: userData.googleId || existingUser.googleId,
        updatedAt: new Date(),
      };
      this.users.set(userId, updatedUser);
      return updatedUser;
    } else {
      const defaultAvatars = [
        "https://api.dicebear.com/7.x/avataaars/svg?seed=Felix&backgroundColor=b6e3f4,c0aede,d1d4f9,ffd5dc,ffdfbf",
        "https://api.dicebear.com/7.x/avataaars/svg?seed=Aneka&backgroundColor=b6e3f4,c0aede,d1d4f9,ffd5dc,ffdfbf",
        "https://api.dicebear.com/7.x/avataaars/svg?seed=Midnight&backgroundColor=b6e3f4,c0aede,d1d4f9,ffd5dc,ffdfbf",
        "https://api.dicebear.com/7.x/avataaars/svg?seed=Shadow&backgroundColor=b6e3f4,c0aede,d1d4f9,ffd5dc,ffdfbf",
        "https://api.dicebear.com/7.x/avataaars/svg?seed=Crow&backgroundColor=b6e3f4,c0aede,d1d4f9,ffd5dc,ffdfbf"
      ];
      const randomAvatar = defaultAvatars[Math.floor(Math.random() * defaultAvatars.length)];
      
      const newUser: User = {
        id: userId,
        email: userData.email || null,
        firstName: userData.firstName || null,
        lastName: userData.lastName || null,
        profileImageUrl: userData.profileImageUrl || randomAvatar,
        isAdmin: false,
        googleId: userData.googleId || null,
        bio: null,
        birthDate: null,
        phoneNumber: null,
        createdAt: new Date(),
        updatedAt: new Date(),
      };
      this.users.set(userId, newUser);
      return newUser;
    }
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.email === email);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const defaultAvatars = [
      "https://api.dicebear.com/7.x/avataaars/svg?seed=Felix&backgroundColor=b6e3f4,c0aede,d1d4f9,ffd5dc,ffdfbf",
      "https://api.dicebear.com/7.x/avataaars/svg?seed=Aneka&backgroundColor=b6e3f4,c0aede,d1d4f9,ffd5dc,ffdfbf",
      "https://api.dicebear.com/7.x/avataaars/svg?seed=Midnight&backgroundColor=b6e3f4,c0aede,d1d4f9,ffd5dc,ffdfbf",
      "https://api.dicebear.com/7.x/avataaars/svg?seed=Shadow&backgroundColor=b6e3f4,c0aede,d1d4f9,ffd5dc,ffdfbf",
      "https://api.dicebear.com/7.x/avataaars/svg?seed=Crow&backgroundColor=b6e3f4,c0aede,d1d4f9,ffd5dc,ffdfbf"
    ];
    const randomAvatar = defaultAvatars[Math.floor(Math.random() * defaultAvatars.length)];
    
    const user: User = {
      id,
      email: insertUser.email || null,
      firstName: insertUser.firstName || null,
      lastName: insertUser.lastName || null,
      profileImageUrl: insertUser.profileImageUrl || randomAvatar,
      isAdmin: false,
      googleId: insertUser.googleId || null,
      bio: insertUser.bio || null,
      birthDate: insertUser.birthDate || null,
      phoneNumber: insertUser.phoneNumber || null,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    this.users.set(id, user);
    return user;
  }

  async updateUser(id: string, updates: Partial<User>): Promise<User | undefined> {
    const user = this.users.get(id);
    if (!user) return undefined;
    
    const updatedUser: User = {
      ...user,
      ...updates,
      updatedAt: new Date(),
    };
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  // Products
  async getProducts(): Promise<Product[]> {
    return Array.from(this.products.values()).sort((a, b) => 
      new Date(b.createdAt!).getTime() - new Date(a.createdAt!).getTime()
    );
  }

  async getProduct(id: string): Promise<Product | undefined> {
    return this.products.get(id);
  }

  async getProductsByCategory(category: string): Promise<Product[]> {
    return Array.from(this.products.values()).filter(
      product => product.category.toLowerCase() === category.toLowerCase()
    );
  }

  async searchProducts(query: string): Promise<Product[]> {
    const lowercaseQuery = query.toLowerCase();
    return Array.from(this.products.values()).filter(
      product => 
        product.title.toLowerCase().includes(lowercaseQuery) ||
        product.description.toLowerCase().includes(lowercaseQuery) ||
        product.tags?.some(tag => tag.toLowerCase().includes(lowercaseQuery))
    );
  }

  async createProduct(insertProduct: InsertProduct): Promise<Product> {
    const id = randomUUID();
    const product: Product = {
      ...insertProduct,
      id,
      rating: "0",
      sales: 0,
      status: "active",
      createdAt: new Date(),
      size: insertProduct.size || null,
      originalPrice: insertProduct.originalPrice || null,
      tags: insertProduct.tags || null,
      isNew: insertProduct.isNew || null,
      isOnSale: insertProduct.isOnSale || null,
    };
    this.products.set(id, product);
    return product;
  }

  async updateProduct(id: string, updates: Partial<Product>): Promise<Product | undefined> {
    const product = this.products.get(id);
    if (!product) return undefined;
    
    const updatedProduct = { ...product, ...updates };
    this.products.set(id, updatedProduct);
    return updatedProduct;
  }

  async deleteProduct(id: string): Promise<boolean> {
    return this.products.delete(id);
  }

  // Orders
  async getOrders(): Promise<Order[]> {
    return Array.from(this.orders.values()).sort((a, b) => 
      new Date(b.createdAt!).getTime() - new Date(a.createdAt!).getTime()
    );
  }

  async getOrder(id: string): Promise<Order | undefined> {
    return this.orders.get(id);
  }

  async getUserOrders(userId: string): Promise<Order[]> {
    return Array.from(this.orders.values()).filter(order => order.userId === userId);
  }

  async createOrder(insertOrder: InsertOrder): Promise<Order> {
    const id = randomUUID();
    const order: Order = {
      ...insertOrder,
      id,
      status: "pending",
      createdAt: new Date(),
      userId: insertOrder.userId || null,
    };
    this.orders.set(id, order);
    return order;
  }

  async updateOrderStatus(id: string, status: string): Promise<Order | undefined> {
    const order = this.orders.get(id);
    if (!order) return undefined;
    
    const updatedOrder = { ...order, status };
    this.orders.set(id, updatedOrder);
    return updatedOrder;
  }

  // Order Items
  async getOrderItems(orderId: string): Promise<OrderItem[]> {
    return Array.from(this.orderItems.values()).filter(item => item.orderId === orderId);
  }

  async createOrderItem(insertOrderItem: InsertOrderItem): Promise<OrderItem> {
    const id = randomUUID();
    const orderItem: OrderItem = {
      ...insertOrderItem,
      id,
      orderId: insertOrderItem.orderId || null,
      productId: insertOrderItem.productId || null,
      quantity: insertOrderItem.quantity || 1,
    };
    this.orderItems.set(id, orderItem);
    return orderItem;
  }

  // User Library
  async getUserLibrary(userId: string): Promise<UserLibrary[]> {
    return Array.from(this.userLibrary.values()).filter(item => item.userId === userId);
  }

  async addToLibrary(insertUserLibrary: InsertUserLibrary): Promise<UserLibrary> {
    const id = randomUUID();
    const userLibrary: UserLibrary = {
      ...insertUserLibrary,
      id,
      isInstalled: false,
      installDate: null,
      lastPlayed: null,
      userId: insertUserLibrary.userId || null,
      productId: insertUserLibrary.productId || null,
    };
    this.userLibrary.set(id, userLibrary);
    return userLibrary;
  }

  async updateLibraryItem(userId: string, productId: string, updates: Partial<UserLibrary>): Promise<UserLibrary | undefined> {
    const item = Array.from(this.userLibrary.values()).find(
      item => item.userId === userId && item.productId === productId
    );
    
    if (!item) return undefined;
    
    const updatedItem = { ...item, ...updates };
    this.userLibrary.set(item.id, updatedItem);
    return updatedItem;
  }

  // Wishlist
  async getUserWishlist(userId: string): Promise<Wishlist[]> {
    return Array.from(this.wishlist.values()).filter(item => item.userId === userId);
  }

  async addToWishlist(insertWishlist: InsertWishlist): Promise<Wishlist> {
    const id = randomUUID();
    const wishlist: Wishlist = {
      ...insertWishlist,
      id,
      createdAt: new Date(),
      userId: insertWishlist.userId || null,
      productId: insertWishlist.productId || null,
    };
    this.wishlist.set(id, wishlist);
    return wishlist;
  }

  async removeFromWishlist(userId: string, productId: string): Promise<boolean> {
    const item = Array.from(this.wishlist.entries()).find(
      ([, wishlist]) => wishlist.userId === userId && wishlist.productId === productId
    );
    
    if (!item) return false;
    
    return this.wishlist.delete(item[0]);
  }
}

export const storage = new MemStorage();
